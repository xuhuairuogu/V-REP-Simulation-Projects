%% LINK CLASS
%   IMPUT OF COSTRUCTOR: 
%   jointType: Prismatic (P), Rotoidal (R)
%   link_num: number of the link in the links vector chain
%   joint_num: number of joint that moves the link
%   previous: previous link in the chain
%   successive: list of successive link in the chain
%   varargin: 
%              1) Without intermediate trasformation | varargin = [a,  alpha, d, theta, offset] , dyn_par
%              2) With intermeiate trasformation | varargin =  [a,alpha,d,theta,offset] , [a_inter,alpha_inter,d_inter,theta_inter], dyn_par;
classdef Link 
    %% PROPERTIES
   properties
        jointType
        kinType
        
        dh = [];
        dh_sym = [];
        dh_inter = [];
        a,  d,   theta,  alpha, offset;
        a_sym,  d_sym,   theta_sym,  alpha_sym, offset_sym;
        a_inter,   d_inter,   theta_inter,    alpha_inter;

        T_inter =eye(4);
        T_sym = eye(4);
        T_sym_DH_sym = eye(4);
         
        q;
        dq;
        ddq;
        link_num;
        joint_num;
        
        previous = []; %link precedente
        successive = []; % vettore di link successivi sempre aggiornato
        
        dyn_par; %vettore dei parametri dinamici del link
        
        I = [];
        m = [];
        mp = [];
        Fv = [];
        Fs = [];
        
        I_sym = sym('0');
        m_sym = sym('0');
        mp_sym = sym('0');
        Fv_sym = sym('0');
        Fs_sym = sym('0');
        
        
    end
    %% COSTRUCTOR
    methods
        function obj=Link(kinType_, jointType_, link_num_, joint_num_, previous_, successive_, varargin)
            %Costructor overload (is possible to use a link with or without
            %intermedian trasformation)
            if nargin == 0 %Only initialization without parametrers
                return;
            end
            obj.kinType = kinType_;
            obj.jointType = jointType_;
            obj.link_num = link_num_;
            obj.joint_num = joint_num_;
            obj.previous = previous_;
            obj.successive = successive_;

            
            obj.q = sym(strcat('q',num2str(obj.joint_num)), 'real');
            obj.dq = sym(strcat('dq',num2str(obj.joint_num)), 'real');
            obj.ddq = sym(strcat('ddq',num2str(obj.joint_num)), 'real');
  
            if nargin == 3+6 %With intermediate trasformation
              
                obj.dh_inter = varargin{2};
                
                obj.a_inter = obj.dh_inter(1);
                obj.alpha_inter =obj.dh_inter(2);
                obj.d_inter = obj.dh_inter(3);
                obj.theta_inter = obj.dh_inter(4);
                
                obj.dyn_par = varargin{3};
                %Intermediate transformation
                obj.T_inter = [cosd(obj.theta_inter), -sind(obj.theta_inter)*cosd(obj.alpha_inter), sind(obj.theta_inter)*sind(obj.alpha_inter), obj.a_inter*cosd(obj.theta_inter);
                                 sind(obj.theta_inter), cosd(obj.theta_inter)*cosd(obj.alpha_inter), -cosd(obj.theta_inter)*sind(obj.alpha_inter), obj.a_inter*sind(obj.theta_inter);
                                 0, sind(obj.alpha_inter), cosd(obj.alpha_inter), obj.d_inter;
                                 0,0,0,1];
            elseif nargin == 2+6 %Without intermediate trasformation
                obj.a_inter = 0;
                obj.alpha_inter =0;
                obj.d_inter = 0;
                obj.theta_inter = 0;
                obj.dyn_par = varargin{2};

            else
                disp('Num of variable incorrect');
            end
            
            if nargin >=2+6
%                 
                obj.dh = varargin{1};
                
                obj.a = obj.dh(1);
                obj.alpha =obj.dh(2);
                obj.d = obj.dh(3);
                obj.theta= obj.dh(4);
                obj.offset= obj.dh(5);
            end
 
            
            %% Create symbolic variable
            if obj.a == 0
                obj.a_sym = sym(0);
            else
                obj.a_sym = sym(strcat('a',num2str(obj.link_num)), 'real');
            end
            if obj.alpha == 0
                obj.alpha_sym = sym(0);
            else
                obj.alpha_sym = sym(strcat('aph',num2str(obj.link_num)), 'real');
            end
            if obj.d == 0
                obj.d_sym = sym(0);
            else
                obj.d_sym = sym(strcat('d',num2str(obj.link_num)), 'real');
            end
            if obj.theta == 0
                obj.theta_sym = sym(0);
            else
                obj.theta_sym = sym(strcat('th',num2str(obj.link_num)), 'real');
            end
            if obj.offset == 0
                obj.offset_sym = sym(0);
            else
                obj.offset_sym = sym(strcat('o',num2str(obj.link_num)), 'real');
            end
            
            obj.dh_sym = [obj.a_sym, obj.alpha_sym, obj.d_sym, obj.theta_sym, obj.offset_sym];

%Create symbolic dynamic variable
            for i = 1:3
                if(i==1) str1='x'; elseif(i==2) str1='y'; else str1='z'; end
                obj.mp_sym(i,1) = sym(strcat('mp',str1,num2str(obj.link_num)), 'real');
                for j = i:3
                    if(j==1) str2='x'; elseif(j==2) str2='y'; else str2='z'; end
                    obj.I_sym(i,j) = sym(strcat('I',str1,str2,num2str(obj.link_num)), 'real');
                    obj.I_sym(j,i) = obj.I_sym(i,j);
                end
                                               
            end
                       
            obj.m_sym = sym(strcat('m',num2str(obj.link_num)), 'real');
            obj.Fv_sym = sym(strcat('Fv',num2str(obj.joint_num)), 'real');
            obj.Fs_sym = sym(strcat('Fs',num2str(obj.joint_num)), 'real');

            %% Symbolic mat with DH symbolic
            %DH transformation rotoidal joint 
            if strcmp(obj.kinType, 'std')
                if strcmp(obj.jointType, 'R')
                   obj.T_sym_DH_sym = [cos(obj.q + obj.offset_sym), -sin(obj.q + obj.offset_sym)*cos(obj.alpha_sym), sin(obj.q + obj.offset_sym)*sin(obj.alpha_sym), obj.a_sym*cos(obj.q + obj.offset_sym);
                                      sin(obj.q + obj.offset_sym), cos(obj.q + obj.offset_sym)*cos(obj.alpha_sym), -cos(obj.q + obj.offset_sym)*sin(obj.alpha_sym), obj.a_sym*sin(obj.q + obj.offset_sym);
                                      0, sin(obj.alpha_sym), cos(obj.alpha_sym), obj.d_sym;
                                      0,0,0,1] * obj.T_inter;

                %DH transformation prismatic joint                   
                elseif strcmp(obj.jointType, 'P')
                    obj.T_sym_DH_sym = [cos(obj.theta_sym), -sin(obj.theta_sym)*cos(obj.alpha_sym), sin(obj.theta_sym)*sin(obj.alpha_sym), obj.a_sym*cos(obj.theta_sym);
                                       sin(obj.theta_sym), cos(obj.theta_sym)*cos(obj.alpha_sym), -cos(obj.theta_sym)*sin(obj.alpha_sym), obj.a_sym*sin(obj.theta_sym);
                                       0, sin(obj.alpha_sym), cos(obj.alpha_sym), obj.q + obj.offset_sym;
                                       0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end
            elseif strcmp(obj.kinType, 'craig')
                if strcmp(obj.jointType, 'R')
                   obj.T_sym_DH_sym = [cos(obj.q + obj.offset_sym), -sin(obj.q + obj.offset_sym), 0, obj.a_sym;
                                      sin(obj.q + obj.offset_sym)*cos(obj.alpha_sym), cos(obj.q + obj.offset_sym)*cos(obj.alpha_sym), -sin(obj.alpha_sym), -obj.d_sym*sin(obj.alpha_sym);
                                      sin(obj.q + obj.offset_sym)*sin(obj.alpha_sym), cos(obj.q + obj.offset_sym)*sin(obj.alpha_sym), cos(obj.alpha_sym), obj.d_sym*cos(obj.alpha_sym);
                                      0,0,0,1] * obj.T_inter;

                %DH transformation prismatic joint                   
                elseif strcmp(obj.jointType, 'P')
                   obj.T_sym_DH_sym = [cos(obj.theta_sym), -sin(obj.theta_sym), 0, obj.a_sym;
                                      sin(obj.theta_sym)*cos(obj.alpha_sym), cos(obj.theta_sym)*cos(obj.alpha_sym), -sin(obj.alpha_sym), -(obj.q + obj.offset_sym)*sin(obj.alpha_sym);
                                      sin(obj.theta_sym)*sin(obj.alpha_sym), cos(obj.theta_sym)*sin(obj.alpha_sym), cos(obj.alpha_sym), (obj.q + obj.offset_sym)*cos(obj.alpha_sym);
                                      0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end        
            else
                disp('Kin type not valid');
            end
            %% Symbolic mat 
            %DH transformation rotoidal joint    
            if isnumeric(obj.offset)
                offset = deg2rad(obj.offset);
            else
                offset = obj.offset;
            end
            if isnumeric(obj.alpha) == 0
                obj.alpha = double(obj.alpha);
            end
            
            if isnumeric(obj.theta) == 0
                obj.theta = double(obj.theta);
            end
            if strcmp(obj.kinType, 'std')
                if strcmp(obj.jointType, 'R')
                   obj.T_sym = [cos(obj.q + offset), -sin(obj.q + offset)*cosd(obj.alpha), sin(obj.q + offset)*sind(obj.alpha), obj.a*cos(obj.q + offset);
                                      sin(obj.q + offset), cos(obj.q + offset)*cosd(obj.alpha), -cos(obj.q + offset)*sind(obj.alpha), obj.a*sin(obj.q + offset);
                                      0, sind(obj.alpha), cosd(obj.alpha), obj.d;
                                      0,0,0,1] * obj.T_inter;

                %DH transformation prismatic joint                   
                elseif strcmp(obj.jointType, 'P')
                    obj.T_sym = [cosd(obj.theta), -sind(obj.theta)*cosd(obj.alpha), sind(obj.theta)*sind(obj.alpha), obj.a*cosd(obj.theta);
                                       sind(obj.theta), cosd(obj.theta)*cosd(obj.alpha), -cosd(obj.theta)*sind(obj.alpha), obj.a*sind(obj.theta);
                                       0, sind(obj.alpha), cosd(obj.alpha), obj.q + obj.offset;
                                       0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end
            elseif strcmp(obj.kinType, 'craig')
                if strcmp(obj.jointType, 'R')
                   obj.T_sym = [cos(obj.q + offset), -sin(obj.q + offset), 0, obj.a;
                                      sin(obj.q + offset)*cosd(obj.alpha), cos(obj.q + offset)*cosd(obj.alpha), -sind(obj.alpha), -obj.d*sind(obj.alpha);
                                      sin(obj.q + offset)*sind(obj.alpha), cos(obj.q + offset)*sind(obj.alpha), cosd(obj.alpha), obj.d*cosd(obj.alpha);
                                      0,0,0,1] * obj.T_inter;

                %DH transformation prismatic joint                   
                elseif strcmp(obj.jointType, 'P')
                   obj.T_sym = [cosd(obj.theta), -sind(obj.theta), 0, obj.a;
                                      sind(obj.theta)*cosd(obj.alpha), cosd(obj.theta)*cosd(obj.alpha), -sind(obj.alpha), -(obj.q + obj.offset)*sind(obj.alpha);
                                      sind(obj.theta)*sind(obj.alpha), cosd(obj.theta)*sind(obj.alpha), cosd(obj.alpha), (obj.q + obj.offset)*cosd(obj.alpha);
                                      0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end        
            else
                disp('Kin type not valid');
            end
            obj.T_sym = simplify(obj.T_sym);
          
        end
        end

    %% METHODS
    methods
        function T_numeric = T_numeric(obj,q) %Calculate numeric DH transformation matrix (q is joint variable)
            if strcmp(obj.kinType, 'std')
                if strcmp(obj.jointType, 'R')

                    T_numeric = [cos(q+ deg2rad(obj.offset)), -sin(q+ deg2rad(obj.offset))*cosd(obj.alpha), sin(q+ deg2rad(obj.offset))*sind(obj.alpha), obj.a*cos(q+ deg2rad(obj.offset));
                                 sin(q+ deg2rad(obj.offset)), cos(q+ deg2rad(obj.offset))*cosd(obj.alpha), -cos(q+ deg2rad(obj.offset))*sind(obj.alpha), obj.a*sin(q+ deg2rad(obj.offset));
                                 0, sind(obj.alpha), cosd(obj.alpha), obj.d;
                                 0,0,0,1] * obj.T_inter;

                elseif strcmp(obj.jointType, 'P')

                    T_numeric = [cosd(obj.theta), -sind(obj.theta)*cosd(obj.alpha), sind(obj.theta)*sind(obj.alpha), obj.a*cosd(obj.theta);
                                 sind(obj.theta), cosd(obj.theta)*cosd(obj.alpha), -cosd(obj.theta)*sind(obj.alpha), obj.a*sind(obj.theta);
                                 0, sind(obj.alpha), cosd(obj.alpha), q + obj.offset;
                                 0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end
            elseif strcmp(obj.kinType, 'craig')
                if strcmp(obj.jointType, 'R')
                   T_numeric = [cos(q + deg2rad(obj.offset)), -sin(q + deg2rad(obj.offset)), 0, obj.a;
                                      sin(q + deg2rad(obj.offset))*cosd(obj.alpha), cos(q + deg2rad(obj.offset))*cosd(obj.alpha), -sind(obj.alpha), -obj.d*sind(obj.alpha);
                                      sin(q + deg2rad(obj.offset))*sind(obj.alpha), cos(q + deg2rad(obj.offset))*sind(obj.alpha), cosd(obj.alpha), obj.d*cosd(obj.alpha);
                                      0,0,0,1] * obj.T_inter;

                %DH transformation prismatic joint                   
                elseif strcmp(obj.jointType, 'P')
                  T_numeric = [cosd(obj.theta), -sind(obj.theta), 0, obj.a;
                                      sind(obj.theta)*cosd(obj.alpha), cosd(obj.theta)*cosd(obj.alpha), -sind(obj.alpha), -(q + obj.offset)*sind(obj.alpha);
                                      sind(obj.theta)*sind(obj.alpha), cosd(obj.theta)*sind(obj.alpha), cosd(obj.alpha), (q + obj.offset)*cosd(obj.alpha);
                                      0,0,0,1] * obj.T_inter;

                else
                    disp('Joint type not valid');
                end        
            else
                disp('Kin type not valid');
            end

                               
        end
    end
end

