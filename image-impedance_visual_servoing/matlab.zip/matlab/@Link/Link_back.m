%% LINK CLASS
%   IMPUT OF COSTRUCTOR: 
%   jointType: Prismatic (P), Rotoidal (R)
%   link_num: number of the link in the links vector chain
%   joint_num: number of joint that moves the link
%   previous: previous link in the chain
%   successive: list of successive link in the chain
%   varargin: 
%              1) Without intermediate trasformation | varargin = [a,  alpha, d, theta, offset] , dyn_par
%              2) With intermeiate trasformation | varargin =  [a,alpha,d,theta,offset] , [a_inter,alpha_inter,d_inter,theta_inter], dyn_par;
classdef Link 
    %% PROPERTIES
   properties
        jointType
        
        dh = [];
        dh_sym = [];
        dh_inter = [];
        a,  d,   theta,  alpha, offset;
        a_sym,  d_sym,   theta_sym,  alpha_sym, offset_sym;
        a_inter,   d_inter,   theta_inter,    alpha_inter;
        
%         r = [0 0 0];
%         p = [0 0 0];
%         r_sym = sym('0');
%         p_sym = sym('0');
%         
%         zita = [];
%         zita_sym = [];
                
        T_inter =eye(4);
        T_sym = eye(4);
        T_sym_DH_sym = eye(4);
         
        q;
        dq;
        ddq;
        link_num;
        joint_num;
        
        previous = []; %link precedente
        successive = []; % vettore di link successivi sempre aggiornato
        
        dyn_par; %vettore dei parametri dinamici del link
        
        I = [];
        m = [];
        mp = [];
        Fv = [];
        Fs = [];
        
        I_sym = sym('0');
        m_sym = sym('0');
        mp_sym = sym('0');
        Fv_sym = sym('0');
        Fs_sym = sym('0');
        
        
    end
    %% COSTRUCTOR
    methods
        function obj=Link(jointType_, link_num_, joint_num_, previous_, successive_, varargin)
            %Costructor overload (is possible to use a link with or without
            %intermedian trasformation)
            if nargin == 0 %Only initialization without parametrers
                return;
            end
            obj.jointType = jointType_;
            obj.link_num = link_num_;
            obj.joint_num = joint_num_;
            obj.previous = previous_;
            obj.successive = successive_;

            
            obj.q = sym(strcat('q',num2str(obj.joint_num)), 'real');
            obj.dq = sym(strcat('dq',num2str(obj.joint_num)), 'real');
            obj.ddq = sym(strcat('ddq',num2str(obj.joint_num)), 'real');
            
            %if strcmp(obj.jointType, 'R_DH') | strcmp(obj.jointType, 'P_DH') 

            if nargin == 3+5 %With intermediate trasformation
              
                obj.dh_inter = varargin{2};
                
                obj.a_inter = obj.dh_inter(1);
                obj.alpha_inter =obj.dh_inter(2);
                obj.d_inter = obj.dh_inter(3);
                obj.theta_inter = obj.dh_inter(4);
                
                obj.dyn_par = varargin{3};
                %Intermediate transformation
                obj.T_inter = [cosd(obj.theta_inter), -sind(obj.theta_inter)*cosd(obj.alpha_inter), sind(obj.theta_inter)*sind(obj.alpha_inter), obj.a_inter*cosd(obj.theta_inter);
                                 sind(obj.theta_inter), cosd(obj.theta_inter)*cosd(obj.alpha_inter), -cosd(obj.theta_inter)*sind(obj.alpha_inter), obj.a_inter*sind(obj.theta_inter);
                                 0, sind(obj.alpha_inter), cosd(obj.alpha_inter), obj.d_inter;
                                 0,0,0,1];
            elseif nargin == 2+5 %Without intermediate trasformation
                obj.a_inter = 0;
                obj.alpha_inter =0;
                obj.d_inter = 0;
                obj.theta_inter = 0;
                obj.dyn_par = varargin{2};

            else
                disp('Num of variable incorrect');
            end
            
            if nargin >=2+5
%                 
                obj.dh = varargin{1};
                
                obj.a = obj.dh(1);
                obj.alpha =obj.dh(2);
                obj.d = obj.dh(3);
                obj.theta= obj.dh(4);
                obj.offset= obj.dh(5);
            end
            
%             elseif strcmp(obj.jointType, 'R_E') || strcmp(obj.jointType, 'P_E') 
%                 
%                 if strcmp(obj.jointType, 'R_E')
%                     obj.r = varargin{1};
%                     obj.p = varargin{2};
%                     obj.offset = varargin{3};
%                     obj.dyn_par = varargin{4};
%                 else
%                     obj.r = varargin{1};
%                     obj.offset = varargin{2};
%                     obj.dyn_par = varargin{3};
%                 end
%           
%             else
%                     disp('Joint type not valid');
%             end
            
            
%             obj.m = obj.dyn_par(1);
%             obj.I = [obj.dyn_par(5) obj.dyn_par(6) obj.dyn_par(7); obj.dyn_par(6) obj.dyn_par(8) obj.dyn_par(9); obj.dyn_par(7) obj.dyn_par(9) obj.dyn_par(10);
%             obj.mp = obj.dyn_par(2:4);
%             obj.Fv = obj.dyn_par(11);
%             obj.Fs = obj.dyn_par(12);
            
            %% Create symbolic variable
            if obj.a == 0
                obj.a_sym = sym(0);
            else
                obj.a_sym = sym(strcat('a',num2str(obj.link_num)), 'real');
            end
            if obj.alpha == 0
                obj.alpha_sym = sym(0);
            else
                obj.alpha_sym = sym(strcat('aph',num2str(obj.link_num)), 'real');
            end
            if obj.d == 0
                obj.d_sym = sym(0);
            else
                obj.d_sym = sym(strcat('d',num2str(obj.link_num)), 'real');
            end
            if obj.theta == 0
                obj.theta_sym = sym(0);
            else
                obj.theta_sym = sym(strcat('th',num2str(obj.link_num)), 'real');
            end
            if obj.offset == 0
                obj.offset_sym = sym(0);
            else
                obj.offset_sym = sym(strcat('o',num2str(obj.link_num)), 'real');
            end
            
            obj.dh_sym = [obj.a_sym, obj.alpha_sym, obj.d_sym, obj.theta_sym, obj.offset_sym];
            
%             for i = 1:3
%                 if(i==1) str='x'; elseif(i==2) str='y'; else str='z'; end
%                     
%                 if obj.r(i) == 0
%                     obj.r_sym(i) = sym('0');
%                 else
%                     obj.r_sym(i) = sym(strcat('r',str,num2str(obj.link_num)), 'real');
%                 end
% 
%                 if obj.p(i) == 0
%                     obj.p_sym(i) = sym('0');
%                 else
%                     obj.p_sym(i) = sym(strcat('p',str,num2str(obj.link_num)), 'real');
%                 end
%             end

%Create symbolic dynamic variable
            for i = 1:3
                if(i==1) str1='x'; elseif(i==2) str1='y'; else str1='z'; end
                obj.mp_sym(i,1) = sym(strcat('mp',str1,num2str(obj.link_num)), 'real');
                for j = i:3
                    if(j==1) str2='x'; elseif(j==2) str2='y'; else str2='z'; end
                    obj.I_sym(i,j) = sym(strcat('I',str1,str2,num2str(obj.link_num)), 'real');
                    obj.I_sym(j,i) = obj.I_sym(i,j);
                end
                                               
            end
                       
            obj.m_sym = sym(strcat('m',num2str(obj.link_num)), 'real');
            obj.Fv_sym = sym(strcat('Fv',num2str(obj.joint_num)), 'real');
            obj.Fs_sym = sym(strcat('Fs',num2str(obj.joint_num)), 'real');

            %% Symbolic mat with DH symbolic
            %DH transformation rotoidal joint    
            if strcmp(obj.jointType, 'R')
               obj.T_sym_DH_sym = [cos(obj.q + obj.offset_sym), -sin(obj.q + obj.offset_sym)*cos(obj.alpha_sym), sin(obj.q + obj.offset_sym)*sin(obj.alpha_sym), obj.a_sym*cos(obj.q + obj.offset_sym);
                                  sin(obj.q + obj.offset_sym), cos(obj.q + obj.offset_sym)*cos(obj.alpha_sym), -cos(obj.q + obj.offset_sym)*sin(obj.alpha_sym), obj.a_sym*sin(obj.q + obj.offset_sym);
                                  0, sin(obj.alpha_sym), cos(obj.alpha_sym), obj.d_sym;
                                  0,0,0,1] * obj.T_inter;
            
            %DH transformation prismatic joint                   
            elseif strcmp(obj.jointType, 'P')
                obj.T_sym_DH_sym = [cos(obj.theta_sym), -sin(obj.theta_sym)*cos(obj.alpha_sym), sin(obj.theta_sym)*sin(obj.alpha_sym), obj.a_sym*cos(obj.theta_sym);
                                   sin(obj.theta_sym), cos(obj.theta_sym)*cos(obj.alpha_sym), -cos(obj.theta_sym)*sin(obj.alpha_sym), obj.a_sym*sin(obj.theta_sym);
                                   0, sin(obj.alpha_sym), cos(obj.alpha_sym), obj.q + obj.offset_sym;
                                   0,0,0,1] * obj.T_inter;
                               
%             elseif strcmp(obj.jointType, 'R_E')
%                 
%                 a_t = -cross(obj.r_sym',obj.p_sym');
%                 b_t= obj.r_sym';
%                 obj.zita_sym = [a_t' b_t']';  
%                 zita_c = sym('0');
%                 zita_c=[ [0 -b_t(3) b_t(2); b_t(3) 0 -b_t(1); -b_t(2) b_t(1) 0], a_t; [0 0 0 0]]; %Rotoidal
%                 
%                 obj.T_sym_DH_sym = simple(expm(zita_c*(obj.q + obj.offset_sym)));
%                 
%             elseif strcmp(obj.jointType, 'P_E')
%                 a_t = obj.r_sym;
%                 b_t= 0;
%                 obj.zita_sym = [a_t' b_t']';  
%                 zita_c = sym('0');
%                 zita_c=[zeros(3,3), a_t; [0 0 0 0]]; %Prismatic
%                 obj.T_sym_DH_sym = simple(expm(zita_c*(obj.q + obj.offset_sym)));
            else
                disp('Joint type not valid');
            end
            
            %% Symbolic mat 
            %DH transformation rotoidal joint    
            if strcmp(obj.jointType, 'R')
               obj.T_sym = [cos(obj.q + deg2rad(obj.offset)), -sin(obj.q + deg2rad(obj.offset))*cosd(obj.alpha), sin(obj.q + deg2rad(obj.offset))*sind(obj.alpha), obj.a*cos(obj.q + deg2rad(obj.offset));
                                  sin(obj.q + deg2rad(obj.offset)), cos(obj.q + deg2rad(obj.offset))*cosd(obj.alpha), -cos(obj.q + deg2rad(obj.offset))*sind(obj.alpha), obj.a*sin(obj.q + deg2rad(obj.offset));
                                  0, sind(obj.alpha), cosd(obj.alpha), obj.d;
                                  0,0,0,1] * obj.T_inter;
            
            %DH transformation prismatic joint                   
            elseif strcmp(obj.jointType, 'P')
                obj.T_sym = [cosd(obj.theta), -sind(obj.theta)*cosd(obj.alpha), sind(obj.theta)*sind(obj.alpha), obj.a*cosd(obj.theta);
                                   sind(obj.theta), cosd(obj.theta)*cosd(obj.alpha), -cosd(obj.theta)*sind(obj.alpha), obj.a*sind(obj.theta);
                                   0, sind(obj.alpha), cosd(obj.alpha), obj.q + deg2rad(obj.offset);
                                   0,0,0,1] * obj.T_inter;
                               
%              elseif strcmp(obj.jointType, 'R_E')
%                a_t = -cross(obj.r,obj.p);
%                b_t= obj.r;
%                obj.zita = [a_t' b_t']';  
%                zita_c=[ [0 -b_t(3) b_t(2); b_t(3) 0 -b_t(1); -b_t(2) b_t(1) 0], a_t; [0 0 0 0]]; %Rotoidal
%                obj.T_sym = simple(expm(zita_c*(obj.q + deg2rad(obj.offset))));
%                
%             elseif strcmp(obj.jointType, 'P_E')
%                a_t = obj.r;
%                b_t= 0;
%                obj.zita = [a_t' b_t']';  
%                
%                zita_c=[zeros(3,3), a_t; [0 0 0 0]]; %Prismatic
%                obj.T_sym = simple(expm(zita_c*(obj.q + obj.offset)));
            else
                disp('Joint type not valid');
            end
          
        end
        end

    %% METHODS
    methods
        function T_numeric = T_numeric(obj,q) %Calculate numeric DH transformation matrix (q is joint variable)
            
            if strcmp(obj.jointType, 'R')
                
                T_numeric = [cos(q+ deg2rad(obj.offset)), -sin(q+ deg2rad(obj.offset))*cosd(obj.alpha), sin(q+ deg2rad(obj.offset))*sind(obj.alpha), obj.a*cos(q+ deg2rad(obj.offset));
                             sin(q+ deg2rad(obj.offset)), cos(q+ deg2rad(obj.offset))*cosd(obj.alpha), -cos(q+ deg2rad(obj.offset))*sind(obj.alpha), obj.a*sin(q+ deg2rad(obj.offset));
                             0, sind(obj.alpha), cosd(obj.alpha), obj.d;
                             0,0,0,1] * obj.T_inter;
                         
            elseif strcmp(obj.jointType, 'P')
                
                T_numeric = [cosd(obj.theta), -sind(obj.theta)*cosd(obj.alpha), sind(obj.theta)*sind(obj.alpha), obj.a*cosd(obj.theta);
                             sind(obj.theta), cosd(obj.theta)*cosd(obj.alpha), -cosd(obj.theta)*sind(obj.alpha), obj.a*sind(obj.theta);
                             0, sind(obj.alpha), cosd(obj.alpha), q + obj.offset;
                             0,0,0,1] * obj.T_inter;
                         
%             elseif strcmp(obj.jointType, 'R_E')
%                zita_c=[ [0 -obj.r(3) obj.r(2); obj.r(3) 0 -obj.r(1); -obj.r(2) obj.r(1) 0], -cross(obj.r,obj.p); [0 0 0 0]]; %Rotoidal
%                T_numeric = expm(zita_c*(q + deg2rad(obj.offset)));
%                
%             elseif strcmp(obj.jointType, 'P_E')
%                zita_c=[zeros(3,3), obj.r; [0 0 0 0]]; %Prismatic
%                T_numeric = expm(zita_c*(q + obj.offset));
            else
                disp('Joint type not valid');
            end
                               
        end
    end
end

