%% RODYMAN CLASS
classdef Robot < handle
    %% Properties
    properties
       
        links;
        first_link = [];
        last_links = [];
        last_links_for_joints = [];
        end_effectors_for_joints = [];
        links_num = 0;
        joints_num = 0;
        kin_type = [];
       
        Tb0 = [];
        
        T_sym;
        T_sym_DH_sym;
                
        Te_sym;
        Te_sym_DH_sym;

        J_sym;
        J_sym_DH_sym;
        
        J_sym_par;
        J_sym_par_DH_sym;
        
        dyn_flag = true;
        Y = [];
        Y_rid = [];
        
        B = [];
        gr = [];
        C_F = [];
        
        B_par_sym = [];
        gr_par_sym = [];
        C_F_par_sym = [];
        
        K = [];
        dyn_par_sym = [];
        dyn_par_sym_rid = [];
        par_ident = [];
        par_ident_rid = [];
        
        par_cad = [];
        
        err = [];
        
 
    end
    %% COSTRUCTOR
    methods
        function obj = Robot(links_, Tb0)
            
            mkdir('Dynamics');
            addpath('Dynamics');
            mkdir('Kinematics');
            addpath('Kinematics');
            
            obj.links = links_;
            obj.links_num = size(obj.links,2);
            obj.kin_type = obj.links(1).kinType;
            
            for j = 1:obj.links_num 
                obj. joints_num = max( obj.joints_num,obj.links(j).joint_num);
                obj.par_cad = [obj.par_cad; obj.links(j).dyn_par];
            end

                obj.Tb0 = Tb0;

          %% Init      
            %obj.kin_type = 1;
            [obj.first_link, obj.last_links, obj.last_links_for_joints, obj.end_effectors_for_joints] = init(obj);
    
            
            %% Symbolic kinematics
            
            [obj.T_sym,  obj.Te_sym]= obj.dirKin(obj.Tb0,'S');
            [obj.T_sym_DH_sym,  obj.Te_sym_DH_sym] = obj.dirKin(obj.Tb0,'DH_S');
            
            try
                [obj.J_sym, obj.J_sym_par] = obj.jacobian(obj.Tb0,'S');
                [obj.J_sym_DH_sym, obj.J_sym_par_DH_sym] = obj.jacobian(obj.Tb0,'DH_S');
            catch err_
                disp('Error in the jacobian calculation');
                obj.err = err_;
                return;
            end

        end
    end
  
  %% KINEMATICS  
  methods
        % DIRKIN 
        [T, T_e] = dirKin(obj,  T_init, sel, varargin);
        T_e = dirKinNum(obj,q);
         % GEOMETRIC JACOBIAN
        [J_sym, J_sym_par] = jacobian(obj, T_init, sel, varargin);
        J = jacobianNum(obj,q);

  end
        
 %% DYNAMIC    
 methods   
         % forward recursion   
         [ w, dw, ddp, w0, dw0, ddp0 ] = fwdRecursion ( obj, init_index, w0, dw0, ddp0 );
         
         [ tau, f, mu ] = bckRecursion( obj, last_index);
         
         [Y,dyn_par_sym] = regressor(obj, init_index);
                  
         [ Y_rid, K, dyn_par_sym_rid ] = riduci( obj );
         
         par_ident = identifica_lmi( obj, q, dq, ddq, tau, K, peso, varargin);
         par_ident = identifica_pinv( obj, q, dq, ddq, tau, peso);
         
         [B, gr, C_F] = dinamicaLagrange(obj, sym_flag);
  
 end
  

    %% USEFUL FUNCTIONS
  
  methods
  
    function S = skew(obj, vec )
        S = [0 -vec(3) vec(2); vec(3) 0 -vec(1); -vec(2) vec(1) 0];
    end 
    
    [J_out, T_out] = kinematicComposition(obj,J1,J2,T1,T2);
    [J_out, T_out] = kinematicTransformation(obj,J,T1,T2);


    mat = parSimplify(obj,mat);
    mat = cCode(obj,mat, fileName, symp, parallel);
    mat = matlabFunction(obj,mat, fileName, symp, parallel,optimize);

   
  end

end

