function [ tau, f, mu ] = bckRecursion( obj, varargin)
disp('BACK---Inizio');
if nargin==1
    last_index = 1;
elseif nargin == 2
    last_index = varargin{1};
else
    error('few variable');
end
%          if length(f_ext) ~= length(obj.Te_sym) || length(mu_ext) ~= length(obj.Te_sym)
%              error( ' Error:...' )
% 
%          end

     last_links_for_joints_temp = obj.last_links_for_joints;

     for i = 1:length(obj.links)

         % creazione delle variabili simboliche
         w_x = sym( strcat( 'wx', int2str(obj.links(i).link_num) ), 'real' );
         w_y = sym( strcat( 'wy', int2str(obj.links(i).link_num) ), 'real' );
         w_z = sym( strcat( 'wz', int2str(obj.links(i).link_num) ), 'real' );
         w{obj.links(i).link_num} = [ w_x; w_y; w_z ];

         dw_x = sym( strcat( 'dwx', int2str(obj.links(i).link_num) ), 'real' );
         dw_y = sym( strcat( 'dwy', int2str(obj.links(i).link_num) ), 'real' );
         dw_z = sym( strcat( 'dwz', int2str(obj.links(i).link_num) ), 'real' );
         dw{obj.links(i).link_num} = [ dw_x; dw_y; dw_z ];

         ddp_x = sym( strcat( 'ddpx', int2str(obj.links(i).link_num) ), 'real' );
         ddp_y = sym( strcat( 'ddpy', int2str(obj.links(i).link_num) ), 'real' );
         ddp_z = sym( strcat( 'ddpz', int2str(obj.links(i).link_num) ), 'real' );
         ddp{obj.links(i).link_num} = [ ddp_x; ddp_y; ddp_z ];

         R = obj.links(i).T_sym(1:3,1:3);
         r_im1_i{i} = R' * ( obj.links(i).T_sym(1:3,4) );



     end

     finish = false;
     link_explored = zeros( length(obj.links), 1);

     i = obj.last_links(1); %link che sto esaminando
     k = obj.last_links(1); %end-effector da cui sto partendo
     f{i} = [0 0 0]';
     mu{i} = [0 0 0]';
     cont = 2;

     while finish == false

     disp(strcat('BACK---Sto computando il link ', int2str(i)));
             R = obj.links(i).T_sym(1:3,1:3);

             if link_explored(i) == 0

                 if strcmp( obj.links(i).jointType, 'P' )
                     f{i} = obj.links(i).m_sym * ddp{i} + cross( dw{i}, obj.links(i).mp_sym ) + cross( w{i}, cross( w{i}, obj.links(i).mp_sym ) );
                     mu{i} = - cross( ddp{i}, obj.links(i).mp_sym ) + obj.links(i).I_sym*dw{i} + cross( w{i}, obj.links(i).I_sym*w{i} );

                 elseif strcmp( obj.links(i).jointType, 'R' )

                     if isempty(obj.links(i).previous)
                         ddp_temp = [sym('ddpx0', 'real') , sym('ddpy0', 'real') , sym('ddpz0', 'real')]';
                     else
                         ddp_temp = ddp{ obj.links(i).previous };
                     end

                     f{i} = obj.links(i).m_sym*R'*ddp_temp + cross( dw{i}, obj.links(i).mp_sym ) + cross( w{i}, cross( w{i}, obj.links(i).mp_sym ) );
                     mu{i} = -cross( R'*ddp_temp, obj.links(i).mp_sym ) + obj.links(i).I_sym*dw{i} + cross( w{i}, obj.links(i).I_sym*w{i} );
                 end
                 
                 

                 link_explored(i) = 1;

             end

             for kk = 1:length(k)
                last_links_for_joints_temp{i} = last_links_for_joints_temp{i}( last_links_for_joints_temp{i} ~= k(kk) );
             end

             if ~isempty( last_links_for_joints_temp{i} ) 

                 k = [ k; last_links_for_joints_temp{i}(1) ];
                 i = k(end);
                 %cont
                 f{i} = [ 0 0 0 ]';
                 mu{i} = [ 0 0 0]';
                 cont = cont + 1;


             else

                 for ii = 1:length( obj.links(i).successive )


                     R_ip1 = obj.links( obj.links(i).successive(ii) ).T_sym(1:3,1:3);
                     if strcmp( obj.links(i).jointType, 'P' )
                         f{i} = f{i} + R_ip1*f{ obj.links(i).successive(ii) };
                         mu{i} = mu{i} + R_ip1*mu{ obj.links(i).successive(ii) };
                     elseif strcmp( obj.links(i).jointType, 'R' )
                         f{i} = f{i} + R_ip1*f{ obj.links(i).successive(ii) };
                         mu{i} = mu{i} + R_ip1*mu{ obj.links(i).successive(ii) } - cross( R_ip1*f{ obj.links(i).successive(ii) }, r_im1_i{i} );
                     end

                 end

                 if strcmp( obj.links(i).jointType, 'P' )
                     mu{i} = mu{i} - cross( f{i}, r_im1_i{i} );
                 end

                 f{i} = obj.parSimplify(f{i});
                 mu{i} = obj.parSimplify(mu{i});
                 
                 if length( obj.links(i).previous  ) == 0 || i == last_index 
                     finish = true;
                 else
                     i = obj.links(i).previous;
                 end

             end

     end
     for i = 1:obj.joints_num
         tau{i} = sym('0');
     end

     for j = 1:obj.links_num 

          R = obj.links(j).T_sym(1:3,1:3);

          if link_explored(j) == 1

              if tau{obj.links(j).joint_num} == 0
                  Fv = obj.links(j).Fv_sym;
                  Fs = obj.links(j).Fs_sym;
              else
                  Fv = 0;
                  Fs = 0;
              end

              if strcmp( obj.links(j).jointType, 'P' )
                 tau{obj.links(j).joint_num} = tau{obj.links(j).joint_num} + f{j}'*R'*[0 0 1]' + Fv*obj.links(j).dq + Fs*sign(obj.links(j).dq);
              elseif strcmp( obj.links(j).jointType, 'R' )
                 tau{obj.links(j).joint_num} = tau{obj.links(j).joint_num} + mu{j}'*R'*[0 0 1]' + Fv*obj.links(j).dq + Fs*sign(obj.links(j).dq);
              end

          end
     end
    disp('BACK---Fine');
     end

