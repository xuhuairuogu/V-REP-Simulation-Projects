% Questo script ricava le matrici del modello in forma di Lagrange a
% partire dall'espressione simboliche delle coppie ricavate dal modello di
% Eulero-Newton
function [B, gr, C_F] = dinamicaLagrange(obj, sym_flag)
disp('DINAMICA_LAGRANGE---Inizio');

theta_ident = obj.par_ident_rid;
theta_sym = obj.dyn_par_sym;

if sym_flag == false & size(theta_ident) == 0;
    error('Devi fare prima lidentificazione dei parametri');
end

B = sym();
C_F = sym();
gr = sym();

for i=1:obj.joints_num
    q(i) = sym(strcat('q', int2str(i)), 'real');
    dq(i) = sym(strcat('dq', int2str(i)), 'real');
    ddq(i) = sym(strcat('ddq', int2str(i)), 'real');
end
    
    
disp('DINAMICA_LAGRANGE---Calcolo delle tau simboliche');

if sym_flag
    tau = obj.Y* theta_sym;
else
    tau = obj.Y_rid * theta_ident;
end


disp('DINAMICA_LAGRANGE---Calcolo di B');

for i = 1:obj.joints_num
    for j = 1:obj.joints_num
        
        b = coeffs( tau(i), ddq(j) );
        if length(b) > 1
            B(i,j) = b(2);
        else
            B(i,j) = sym(0);
        end
    end
        
end

disp('DINAMICA_LAGRANGE---Calcolo di gr');

for i = 1:obj.joints_num
    
    is = int2str(i);
    
    string = strcat( 'ddq',is, '=0');
    evalc(string);
end
tau2 = tau;   
tau2 = subs( tau2 );

for i = 1:obj.joints_num
    
    is = int2str(i);
    
    string = strcat( 'dq',is, '=0');
    evalc(string);
    
    string = strcat( 'ddq',is, '=0');
    evalc(string);
end
tau1 = tau;   
gr = subs( tau1 );

disp('DINAMICA_LAGRANGE---Calcolo di C_F');

C_F = tau2  - gr;

disp('DINAMICA_LAGRANGE---Fine');
