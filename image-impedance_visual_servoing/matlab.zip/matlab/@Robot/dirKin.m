
function [T, T_e] = dirKin(obj,  T_init, sel, varargin)

if strcmp(sel,'N')==0 disp('DIRKIN----Inizio'); end
init_index = 1;
i = init_index;
k = i; % indici dell inizio di rami ancora da esplorare ( pila )

T_old{i} = T_init;
finish1 = false;
finish2 = false;


while finish1 == false % Mi dice che ci sono ancora catene da esplorare
   while finish2 == false;  % Mi dice che la catena che sto esplorando non � finita

       i = k(1);
       k = k(2:end);
       switch sel
           case 'S'
               T_actual = obj.links(i).T_sym;
           case 'DH_S'
               T_actual = obj.links(i).T_sym_DH_sym;
           case 'N'
               q = varargin{1}(obj.links(i).joint_num);
               T_actual = obj.links(i).T_numeric(q);
       end

       T{i} = T_old{i} * T_actual;

        if isempty( obj.links(i).successive )
             finish2 = true;
        else
            k = [ obj.links(i).successive, k ];

            for ii = 1 : length( obj.links(i).successive )
            T_old{  obj.links(i).successive(ii) } = T{i};

           end
        end

   end

   if isempty(k)
       finish1 = true;
   else
       finish2 = false;
   end

end

for iii = 1 : length( obj.last_links )
        if obj.kin_type == 2
            T_e{iii} = T{obj.last_links(iii)} * obj.Te0{iii};
        else
            T_e{iii} = T{obj.last_links(iii)};
        end
end

if strcmp(sel,'N')==0 disp('DIRKIN----Fine'); end

end

