% forward recursion   
function [ w, dw, ddp, varargout ] = fwdRecursion ( obj, varargin)

disp('FORWARD---Inizio');
g = 9.81;


if nargin==1
    init_index = 1;
    gravity = obj.Tb0(1:3,1:3)'*[0 0 g]';
    ddp0 = gravity;
    dw0 = [0 0 0]';
    w0 = [0 0 0]';
elseif nargin == 2
    init_index = varargin{1};
    if init_index == 1
        gravity = obj.Tb0(1:3,1:3)'*[0 0 g]';
    else
        gravity = obj.T_sym{obj.links(init_index).previous}(1:3,1:3)'*[0 0 g]';
    end
    ddp0 = gravity;
    dw0 = [0 0 0]';
    w0 = [0 0 0]';
elseif nargin == 5
    init_index = varargin{1};
    if init_index == 1
        gravity = obj.Tb0(1:3,1:3)'*[0 0 g]';
    else
        gravity = obj.T_sym{obj.links(init_index).previous}(1:3,1:3)'*[0 0 g]';
    end
    ddp0 = gravity + varargin(4);
    dw0 = varagin(3);
    w0 = varargin(2);
else
    error('few input variable');
end

if nargout == 6
    varargout{1} = w0;
    varargout{2} = dw0;
    varargout{3} = ddp0;
elseif nargout == 3
    
else
    error('few out variables');
end

 z0 = [ 0 0 1 ]';
 i = init_index;
 k = []; % indici dell inizio di rami ancora da esplorare ( pila )


 R = obj.links(i).T_sym(1:3,1:3);

 r_i_im1 = R' * ( obj.links(i).T_sym(1:3,4) );


 q = obj.links(i).q;
 dq = obj.links(i).dq;
 ddq = obj.links(i).ddq;

disp(strcat('FORWARD---Sto computando il link ', int2str(i)));
 if strcmp( obj.links(i).jointType, 'P' )
     w{i} = R' * w0;
     dw{i} = R' * dw0;
     ddp{i} = R' * ( ddp0 + ddq * z0 ) + 2*dq* cross( w0, R'*z0 );

 elseif strcmp( obj.links(i).jointType, 'R' )
     w{i} = R'* ( w0 + dq * z0 );
     dw{i} = R'* ( dw0 + ddq*z0 + dq* cross( w0, z0 ) );
     ddp{i} = R' * ddp0 + cross( dw{i}, r_i_im1 ) + cross( w{i}, cross( w{i}, r_i_im1 ) );

 end
w{i} = obj.parSimplify(w{i});
dw{i} = obj.parSimplify(dw{i});
ddp{i} = obj.parSimplify(ddp{i});
 finish1 = false;
 finish2 = false;

 if isempty( obj.links(i).successive )
    finish2 = true;
 else
    k = [ obj.links(i).successive, k ];
 end


 while finish1 == false
     while finish2 == false
         

        i = k(1);
        
        disp(strcat('FORWARD---Sto computando il link ', int2str(i)));
        im1 = obj.links(i).previous;
        k = k(2:end);

        R = obj.links(i).T_sym(1:3,1:3);
        r_i_im1 = R' * obj.links(i).T_sym(1:3,4);

        q = obj.links(i).q;
        dq = obj.links(i).dq;
        ddq = obj.links(i).ddq;

        if strcmp( obj.links(i).jointType, 'P' )
             w{i} = R' * w{im1};
             dw{i} = R' * dw{im1};
             ddp{i} = R' * ( ddp{im1} + ddq * z0 ) + 2*dq* cross( w{im1}, R'*z0 );

        elseif strcmp( obj.links(i).jointType, 'R' )
             w{i} = R'* ( w{im1} + dq * z0 );
             dw{i} = R'* ( dw{im1} + ddq*z0 + dq* cross( w{im1}, z0 ) );
             ddp{i} = R' * ddp{im1} + cross( dw{i}, r_i_im1 ) + cross( w{i}, cross( w{i}, r_i_im1 ) );

        end
        
        simp(1:3,1)=w{i};
        simp(4:6,1)=dw{i};
        simp(7:9,1)=ddp{i};
        
        simp=obj.parSimplify(simp);
       
        w{i} = simp(1:3,1);
        
        dw{i} = simp(4:6,1);
        
        ddp{i} = simp(7:9,1);

        if isempty( obj.links(i).successive )
             finish2 = true;
        else
            k = [ obj.links(i).successive, k ];


        end
 
     end

     if isempty(k)
       finish1 = true;
   else
       finish2 = false;
   end

 end

disp('FORWARD---Fine');
end
