function delta_ident = identifica_lmi(obj, q, dq, ddq, tau ,K, peso, varargin )
    %UNTITLED2 Summary of this function goes here
    %   Detail
    
    n_par = 12;
    n_link = obj.links_num;
    W_tot = [];
    W_rid = [];
    W_nP = [];
    w = [];
    %%Costruisco il mega regressore coin un mega FOR
    
    disp('IDENTIFICA----Calcolo regressore numerico sulla traiettoria specificata')
    
    f = 0.1;
    Ts = 0.005;
    
    init = 200  + ceil( 1000*rand() );
    last= init + 1/f/Ts;

    for i = init:last
        
        
        W1 = regressorNumRid(q(:,i), dq(:,i), ddq(:,i));
        
        W_rid = [W_rid; W1];
        
        w = [w; tau(:,i)];

    end
    
    if peso 
        disp('peso')
        
        for i = 1:length( W_rid(1,:) )
            n = norm( W_rid(:,i) );
            W_rid(:,i) = W_rid(:,i) / n;
            p(i) = 1/n;
        end 
        
    else
        disp( 'non peso' )
        p = ones( 1, length( W_rid(1,:) ) );
        
    end
    
    P = diag(p);
    P_inv = inv(P);
    cond_W = cond(W_rid)

    %%Decomposizione QR di W
    disp('IDENTIFICA----Calcolo decomposizione QR del regressore')
    [m,n] = size(W_rid);
    [Q,R] = qr(W_rid);
    Q1 = Q(1:m, 1:n);
    Q2 = Q(1:m, n+1:(m-n));
    R1 = R(1:n, 1:n);

    u0 = norm(Q2'*w, 2);

    ro1 = Q1'*w;

    eps = 1e-15;
    
    delta_cad = obj.par_cad;
    

    disp('IDENTIFICA----Ottimizzazione')
    cvx_begin sdp
    
        %cvx_solver sedumi
         cvx_precision('medium')

        variable delta(n_par*n_link,1)
        
        variable u

        disp('IDENTIFICA----Calcolo del vincolo')
        for i = 1:n_link
            L(1,:) = [delta(5 + n_par*(i-1)) delta(6 + n_par*(i-1)) delta(7 + n_par*(i-1))];
            L(2,:) = [delta(6 + n_par*(i-1)) delta(8 + n_par*(i-1)) delta(9 + n_par*(i-1))];
            L(3,:) = [delta(7 + n_par*(i-1)) delta(9 + n_par*(i-1)) delta(10 + n_par*(i-1))];
            S = obj.skew( delta(2 + n_par*(i-1):4 + n_par*(i-1)) );
            M = ( delta(1 + n_par*(i-1)) )*eye(3);
        
            D{i} = [L S' ; S M];
            f = blkdiag(delta(11 + n_par*(i-1)), delta(12 + n_par*(i-1)) );
            E{i} = blkdiag(D{i}, f);
        end

        E_bar = blkdiag(E{1:n_link});

        E_bar = E_bar - eps*eye(size(E_bar));

        U = [u - u0, (ro1- R1*P_inv*K*delta)'; ro1 - R1*P_inv*K*delta, eye(n)];
               
        variable F(length(U)+length(E_bar),length(U)+length(E_bar))  hermitian
        
        F == blkdiag(U, E_bar);
        
        F>=0;
        
        try 
            if nargin == 7+2
                
                delta(varargin{1})==varargin{2};
                
            elseif nargin == 7+3
                
                delta(varargin{1}) >= varargin{2};
                delta(varargin{1}) <= varargin{3};
                
            end
            
        catch err_
            disp('Error in the specific of the values of parameters')
            obj.err = err_;
            return;
        end

        minimize(u);

    cvx_end
    
    delta_ident = delta;
    beta_ident = K * delta;

    disp('IDENTIFICA----Ottimizzazione completata!!!!')

    
    delta_ident = delta;

end




