function beta_ident = identifica_pinv(obj, q, dq, ddq, tau, peso)
    %UNTITLED2 Summary of this function goes here
    %   Detail
    n_par = 12;
    n_link = obj.links_num;
    W = [];
    w = [];
    %%Costruisco il mega regressore coin un mega FOR
    
    disp('IDENTIFICA----Calcolo regressore numerico sulla traiettoria specificata')
    
    f = 0.1;
    Ts = 0.005;
    init = 500;
    last= init + 1/f/Ts;
    
    for i = init:last

        W1 = regressorNumRid(q(:,i), dq(:,i), ddq(:,i));
        W = [W; W1];

        w = [w; tau(:,i)];

    end
    
    if peso
        
        for i = 1:length( W(1,:) )
            p(i) = 1/norm(W(:,i));
            W(:,i) = p(i)*W(:,i);
        end
        
    else
        
        p = ones(1, length(W(1,:)) );
        
    end
    
    P = diag(p);
   
    cond_W = cond(W)

    disp('IDENTIFICA----Ottimizzazione')
       
    beta_ident = P * pinv(W) * w;
    
   
    
    disp('IDENTIFICA----Ottimizzazione completata!!!!')
    
    


end




