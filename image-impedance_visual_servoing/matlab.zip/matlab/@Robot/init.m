function [first_link, last_links, last_links_for_joints, end_effectors_for_joints] = init(obj)

        %Calcolo dell' ultimo link per ogni giunto
       for j = 1:obj.links_num 
            i = j;
           k = i; % indici dell inizio di rami ancora da esplorare ( pila )

           finish1 = false;
           finish2 = false;
           last_links_temp = [];

           while finish1 == false % Mi dice che ci sono ancora catene da esplorare
                   while finish2 == false;  % Mi dice che la catena che sto esplorando non � finita
                   i = k(1);
                   k = k(2:end);

                    if isempty( obj.links(i).successive )
                         finish2 = true;
                         last_links_temp = [last_links_temp, obj.links(i).link_num];
                   else
                        k = [ obj.links(i).successive, k ];
                    end
               end

               if isempty(k)
                   finish1 = true;
               else
                   finish2 = false;
               end

           end
            last_links_for_joints{j}=last_links_temp;

       end

        % Calcolo dell ultimo link e del primo

        for i= 1:length(obj.links)
            if length( obj.links(i).previous ) == 0
            first_link = obj.links(i).link_num;
            end

        end

        last_links = last_links_for_joints{1};

        for i= 1:length(obj.links)
            end_effectors_for_joints{i} = find(ismember(last_links,  last_links_for_joints{i}) == 1);
        end

end

