% GEOMETRIC JACOBIAN
function [J_sym, J_sym_par] = jacobian(obj, T_init, sel, varargin)
init_index = 1;
if strcmp(sel,'N')==0 disp('JACOBIAN----Inizio'); end

J_sym_par = {};

switch sel
   case 'S'
       T_actual = obj.T_sym;
       Te_actual = obj.Te_sym;
   case 'DH_S'
       T_actual = obj.T_sym_DH_sym;
       Te_actual =obj.Te_sym_DH_sym;
   case 'N'
      [T_actual, Te_actual] = obj.dirKin(T_init,'N',varargin{1});
end

chain_num = length(obj.last_links); 

for i = 1:obj.links_num

          if strcmp(obj.links(i).kinType,'std')

            if i==1
               p_im1=T_init(1:3,4);
               z_im1=T_init(1:3,3);
            else
               z_im1 = T_actual{obj.links(i).previous}(1:3,3);
               p_im1 = T_actual{obj.links(i).previous}(1:3,4);
            end
            
          elseif strcmp(obj.links(i).kinType,'craig')

               z_im1 = T_actual{i}(1:3,3);
               p_im1 = T_actual{i}(1:3,4);
           
          end
          
      for j = 1:chain_num
        if isempty(find(obj.end_effectors_for_joints{i}==j,1))
            
        else
             p_e = Te_actual{j}(1:3,4);

            if strcmp(obj.links(i).jointType,'R') % Rotoidal joints
                J(:,i)=[cross(z_im1,(p_e-p_im1)); z_im1];

            elseif strcmp(obj.links(i).jointType,'P') % Prismatic joints
                J(:,i)=[z_im1; zeros(3,1)];
            else
                disp('joint not valid');

            end

            J_sym(1 + (j - 1)*6 :6 + (j - 1)*6 ,obj.links(i).joint_num) = J(:,i);
        end
      end

%         else
%              if i==init_index-1
%                J{i+1}=obj.links(i+1).zita;
%              else
%                %zita_p = adjoint(obj.T_sym{i})*obj.links(i+1).zita;
%                %J{i+1} = zita_p;
%                J{i+1} = [0 0 0 0 0 0]';
%             end
% 
%         end

end


%% Jacobiani parziali

for j = 1:obj.links_num
    finish = false;    
    p_e = T_actual{j}(1:3,4);
    
    i = j;
    J_sym_par{j} = [];
    
    while finish == false
        
        if i==1
            finish = true;
        end
        if strcmp(obj.links(i).kinType,'std')

            if i==1
                p_im1=T_init(1:3,4);
                z_im1=T_init(1:3,3);
            else
                z_im1 = T_actual{obj.links(i).previous}(1:3,3);
                p_im1 = T_actual{obj.links(i).previous}(1:3,4);
            end

        elseif strcmp(obj.links(i).kinType,'craig')

            z_im1 = T_actual{i}(1:3,3);
            p_im1 = T_actual{i}(1:3,4);

        end
        
        
        if strcmp(obj.links(i).jointType,'R') % Rotoidal joints
            J_sym_par{j}=[ [cross(z_im1,(p_e-p_im1)); z_im1], J_sym_par{j} ];

        elseif strcmp(obj.links(i).jointType,'P') % Prismatic joints
            J_sym_par{j}=[ [z_im1; zeros(3,1)] , J_sym_par{j} ];
        else
            disp('joint not valid');

        end
        
        i = obj.links(i).previous;
        
    end
    
end

if strcmp(sel,'N')==0 disp('JACOBIAN----Fine'); end

end

