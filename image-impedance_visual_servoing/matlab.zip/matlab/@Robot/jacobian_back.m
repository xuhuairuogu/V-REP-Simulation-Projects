% GEOMETRIC JACOBIAN
function [J_sym, J_sym_par] = jacobian(obj, T_init, sel, varargin)
init_index = 1;
if strcmp(sel,'N')==0 disp('JACOBIAN----Inizio'); end

J_sym_par = {};

i = 1;
k = i; % indici dell inizio di rami ancora da esplorare ( pila )
J_sym_temp = sym(0);

switch sel
   case 'S'
       T_actual = obj.T_sym;
       Te_actual = obj.Te_sym;
   case 'DH_S'
       T_actual = obj.T_sym_DH_sym;
       Te_actual =obj.Te_sym_DH_sym;
   case 'N'
      [T_actual, Te_actual] = obj.dirKin(T_init,'N',varargin{1});
end

finish1 = false;
finish2 = false;
chain_num=1; 


while finish1 == false % Mi dice che ci sono ancora catene da esplorare
    while finish2 == false;  % Mi dice che la catena che sto esplorando non � finita

       i = k(1);
       
       k = k(2:end);
       
      %  if obj.kin_type ==1
          if strcmp(obj.links(i).kinType,'std')

            if i==1
               p_im1=T_init(1:3,4);
               z_im1=T_init(1:3,3);
            else
               z_im1 = T_actual{obj.links(i).previous}(1:3,3);
               p_im1 = T_actual{obj.links(i).previous}(1:3,4);
            end
            
          elseif strcmp(obj.links(i).kinType,'craig')

               z_im1 = T_actual{i}(1:3,3);
               p_im1 = T_actual{i}(1:3,4);
           
          end

        p_e = Te_actual{chain_num}(1:3,4);

        if strcmp(obj.links(i).jointType,'R') % Rotoidal joints
            J{i}=[cross(z_im1,(p_e-p_im1)); z_im1];

        elseif strcmp(obj.links(i).jointType,'P') % Prismatic joints
            J{i}=[z_im1; zeros(3,1)];
        else
            disp('joint not valid');

        end
                
%         else
%              if i==init_index-1
%                J{i+1}=obj.links(i+1).zita;
%              else
%                %zita_p = adjoint(obj.T_sym{i})*obj.links(i+1).zita;
%                %J{i+1} = zita_p;
%                J{i+1} = [0 0 0 0 0 0]';
%             end
% 
%         end

         for j=1:6

           J_sym_temp(j,i) = J{i}(j); % Position jacobian

         end

        if isempty( obj.links(i).successive )
            finish2 = true;

        else

            k = [ obj.links(i).successive, k ];

        end

    end
      chain_num = chain_num +1;

   if isempty(k)
       finish1 = true;
   else
       finish2 = false;
   end

end
%Ricostruisco lo Jacobiano totale
for j = 1:obj.links_num 
    for i = 1:length(obj.end_effectors_for_joints{j})
       J_sym(1 + (obj.end_effectors_for_joints{j}(i) - 1)*6 :6 + (obj.end_effectors_for_joints{j}(i) - 1)*6 ,obj.links(j).joint_num ) = J_sym_temp(:,j);
    end
end
 
%J_sym = simplify(J_sym);

if strcmp(sel,'S')==1
%     %Creazione funzione numerica
%     scriptname = sprintf('%s.m', '@Robot/jacobianNum');
%     fid = fopen(scriptname, 'wt'); %and use 't' with text files so eol are properly translated
%     funname = 'jacobianNum';
%     fprintf(fid, 'function J = %s(obj, q)\n\n', funname);
% 
%     for i=1:obj.joints_num
%         fprintf(fid, 'q%d = q(%d);\n', i, i);
%     end
% 
%     for i=1:size(J_sym,1)
%         for j=1:size(J_sym,2)
%             fprintf(fid, 'J(%d,%d) = %s;\n', i, j, char(J_sym(i,j)));
%         end
%     end
% 
%     fclose(fid);
mat = obj.matlabFunction(J_sym, 'Kinematics/jacobianNum', false, false, true);


end
if strcmp(sel,'N')==0 disp('JACOBIAN----Fine'); end


%% Jacobiani parziali

for j = 1:obj.links_num
finish = false;    
    p_e = T_actual{j}(1:3,4);
    
    i = j;
    J_sym_par{j} = [];
    
    while finish == false
        
        
        if strcmp(obj.links(i).kinType,'std')

            if i==1
                p_im1=T_init(1:3,4);
                z_im1=T_init(1:3,3);
                finish = true;
            else
                z_im1 = T_actual{obj.links(i).previous}(1:3,3);
                p_im1 = T_actual{obj.links(i).previous}(1:3,4);
            end

        elseif strcmp(obj.links(i).kinType,'craig')

            z_im1 = T_actual{i}(1:3,3);
            p_im1 = T_actual{i}(1:3,4);

        end
        
        
        if strcmp(obj.links(i).jointType,'R') % Rotoidal joints
            J_sym_par{j}=[ [cross(z_im1,(p_e-p_im1)); z_im1], J_sym_par{j} ];

        elseif strcmp(obj.links(i).jointType,'P') % Prismatic joints
            J_sym_par{j}=[ [z_im1; zeros(3,1)] , J_sym_par{j} ];
        else
            disp('joint not valid');

        end
        
        i = obj.links(i).previous;
        
    end
    
end


end

