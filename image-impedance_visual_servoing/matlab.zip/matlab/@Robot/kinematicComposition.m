
function [J_out, T_out] = kinematicComposition(obj,J1,J2,T1,T2)
                    
T_out= T1*T2;                     
R=[T1(1:3,1:3) zeros(3,3); zeros(3,3) T1(1:3,1:3)];

G=[eye(3), -obj.skew(T_out(1:3,4)-T1(1:3,4));
    zeros(3,3) eye(3)];


J_out=[G*J1 R*J2];

end


