
function mat = matlabFunction(obj,mat, fileName, symp, parallel,optimize)

   disp('MFUNCTION----Creo il file .m');
    for h=1:obj.joints_num
        evalc(strcat('syms q',int2str(h), ' real' ));
        evalc(strcat('syms dq',int2str(h), ' real' ));
        evalc(strcat('syms ddq',int2str(h), ' real' ));

        evalc(strcat('q(',int2str(h), ')=q',int2str(h) ));
        evalc(strcat('dq(',int2str(h), ')=dq',int2str(h) ));
        evalc(strcat('ddq(',int2str(h), ')=ddq',int2str(h) ));
    end

    if parallel
        for i = 1:size(mat,1)
            mat_{i} = mat(i,:);
        end
        n = length(mat_);
        q_{1} = q;
        dq_{1} = dq;
        ddq_{1} = ddq;
        parfor i=1:n

            if symp 
                disp(strcat('MFUNCTION----Semplifica l elemento: ', int2str(i), ' di: ' , int2str(n)));
                mat_{i} = simplify(mat_{i});
            end
            disp(strcat('MFUNCTION----Creo il file .m dell elemento: ', int2str(i), ' di: ' , int2str(n)));
            fileName_ = strcat(fileName,int2str(i));


            try
                matlabFunction(mat_{i},'file',fileName_, 'Optimize', optimize,'Vars',{q_{1}, dq_{1}, ddq_{1}});
            catch err_
                disp('Non � possibile calcolare la matlabFunction non ottimizzata, la tua versione di matlab � precedente alla 2015!!!');
                matlabFunction(mat_{i},'file',fileName_, 'Vars',{q_{1}, dq_{1}, ddq_{1}});

            end

        end
        for i = 1:size(mat,1)
            mat(i,:) = mat_{i};
        end

    else
    if symp 
          disp('MFUNCTION----Semplifica la matrice');
          mat = obj.parSimplify(mat);
    end   
    try
        matlabFunction(mat,'file',fileName, 'Optimize', optimize, 'Vars', {q, dq, ddq});
    catch err_
        matlabFunction(mat,'file',fileName, 'Vars', {q, dq, ddq});
    end

    end
end

