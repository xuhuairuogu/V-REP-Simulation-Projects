function [Y,PI] = regressor(obj, init_index)

disp('REGRESSOR---Inizio regressor');

if strcmp(obj.kin_type, 'craig')
    error('The dynamics calculation is not implemented for craig DH formulation');
end

[ w, dw, ddp, w0, dw0, ddp0 ] = obj.fwdRecursion (init_index);
save fwd.mat w dw ddp w0 dw0 ddp0;
[ tau, f, mu ] = obj.bckRecursion(init_index);
save bck.mat tau f mu;
 PI = [];
disp('REGRESSOR---Sostituzione variabili w, dw, ddp');

parfor j = 1:length(tau)
%tau{j} = simplify(tau{j});
disp(strcat('REGRESSOR---Subs variable:0 to tau:', int2str(j)));
tau{j} = subs(tau{j}, strcat( 'wx', '0' ), w0(1) );
tau{j} = subs(tau{j}, strcat( 'wy', '0'), w0(2) );
tau{j} = subs(tau{j}, strcat( 'wz', '0' ), w0(3) );

tau{j} = subs(tau{j}, strcat( 'dwx', '0' ), dw0(1) );
tau{j} = subs(tau{j}, strcat( 'dwy', '0' ), dw0(2) );
tau{j} = subs(tau{j}, strcat( 'dwz', '0' ), dw0(3) );

tau{j} = subs(tau{j}, strcat( 'ddpx', '0' ), ddp0(1) );
tau{j} = subs(tau{j}, strcat( 'ddpy', '0' ), ddp0(2) );
tau{j} = subs(tau{j}, strcat( 'ddpz', '0' ), ddp0(3) );
for i = init_index:obj.links_num
    disp(strcat('REGRESSOR---Subs variable: ', int2str(i),' to tau: ', int2str(j)));
     tau{j} = subs(tau{j}, strcat( 'wx', int2str(obj.links(i).link_num) ), w{i}(1) );
     tau{j} = subs(tau{j}, strcat( 'wy', int2str(obj.links(i).link_num) ), w{i}(2) );
     tau{j} = subs(tau{j}, strcat( 'wz', int2str(obj.links(i).link_num) ), w{i}(3) );

     tau{j} = subs(tau{j}, strcat( 'dwx', int2str(obj.links(i).link_num) ), dw{i}(1) );
     tau{j} = subs(tau{j}, strcat( 'dwy', int2str(obj.links(i).link_num) ), dw{i}(2) );
     tau{j} = subs(tau{j}, strcat( 'dwz', int2str(obj.links(i).link_num) ), dw{i}(3) );

     tau{j} = subs(tau{j}, strcat( 'ddpx', int2str(obj.links(i).link_num) ), ddp{i}(1) );
     tau{j} = subs(tau{j}, strcat( 'ddpy', int2str(obj.links(i).link_num) ), ddp{i}(2) );
     tau{j} = subs(tau{j}, strcat( 'ddpz', int2str(obj.links(i).link_num) ), ddp{i}(3) );
end
%tau{j} = simplify(tau{j});

end

save tausubs.mat tau;

for i = init_index:obj.links_num
    PI_temp{i}(1) = obj.links(i).m_sym;
    PI_temp{i}(2:4) = obj.links(i).mp_sym;
    PI_temp{i}(5) = obj.links(i).I_sym(1,1);
    PI_temp{i}(6) = obj.links(i).I_sym(2,1);
    PI_temp{i}(7) = obj.links(i).I_sym(3,1);
    PI_temp{i}(8) = obj.links(i).I_sym(2,2);
    PI_temp{i}(9) = obj.links(i).I_sym(2,3);
    PI_temp{i}(10) = obj.links(i).I_sym(3,3);
    PI_temp{i}(11) = obj.links(i).Fv_sym;
    PI_temp{i}(12) = obj.links(i).Fs_sym;
    
    PI = [PI; PI_temp{i}'];
end

% calcolo dei termini del regressore
disp('REGRESSOR---Calcolo dei coefficienti del regressore');
parfor i=1:obj.joints_num
   % tau{i} = simplify(tau{i});

    for k=1:length(PI)
        disp(strcat('REGRESSOR---Compute coeffs for the variable: ', int2str(k),' to tau: ', int2str(i)));
        c = coeffs( tau{i}, PI(k) );
        if length(c) > 1
            phi{i}(k) = c(2);
        else
            phi{i}(k) = sym('0');
        end
    end
end

save phi.mat phi;

for i=1:obj.joints_num
    for k=1:length(PI)
       Y(i,k) = phi{i}(k);
    end
end

end

