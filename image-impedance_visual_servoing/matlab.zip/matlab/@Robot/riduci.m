
function [ Y_rid, K, PI_rid ] = riduci( obj )
disp('RIDUCI---Inizio riduci');
if strcmp(obj.kin_type, 'craig')
    error('The dynamics calculation is not implemented for craig DH formulation');
end


% dal regressore completo (simbolico) al regressore ridotto (simbolico)
% genera i files:
%   paramc.mat
%   regressorenumerico150x89.mat
%   regressoreridotto.mat
%   regr.txt


%% PARAMC

M = 10;
npti = M * obj.joints_num;
delta = 1;
tra = pi - 2*pi*rand(npti,3*obj.joints_num);

obj.links_num
npar = 12*obj.links_num;

tol=1e-9;


% calcola regressore per piu' punti
P = [];
disp('RIDUCI---Calcolo il regressore numerico');

for i=1:npti
    for j=1:obj.joints_num
        disp(strcat('RIDUCI---Calcolo il punto ',int2str(i),' del giunto ' ,int2str(j)));
        evalc(strcat('P1 = regressorNum', int2str(j), '(tra(i,1:obj.joints_num), tra(i,obj.joints_num+1:2*obj.joints_num), tra(i,2*obj.joints_num+1:3*obj.joints_num) );'));
        %P1 = obj.regressorNum( tra(i,j), tra(i,obj.joints_num+j), tra(i,2*obj.joints_num+j) );
         P = [P; P1];
    end
  
end

disp('RIDUCI---Calcolo svd');


[U,S,V] = svd(P,0);
p = rank(S);

V1 = V(:,1:p);
V2 = V(:,p+1:npar);

% costruisce i vettori contenenti gli indici dei parametri non identificabili
% ed identificabili isolatamente; elimina le colonne corrispondenti in P
Xni = [];
Xi = [];
nP = [];
disp('RIDUCI---Costruisce i vettori contenenti gli indici dei parametri non identificabili ed identificabili isolatamente');

for i=1:npar,
    if (norm(V1(i,:))<tol),
          Xni = [Xni; i];
    elseif (norm(V2(i,:))<tol),
          Xi = [Xi; i];
    else
        nP = [nP P(:,i)];
    end
end

clear U S V V1 V2

[mm,nn]=size(nP);
[U,S,V] = svd(nP,0);
pp = rank(S);       

V1 = V(:,1:pp);
V2 = V(:,pp+1:nn);

V21 = zeros(pp,nn-pp);
V22 = zeros(nn-pp,nn-pp);

oldr = 0;
X1 = zeros(pp,1);
X2 = zeros(nn-pp,1);
cont22 = nn-pp;
cont21 = pp;

% costruisce le matrici V11 e V22; non tiene conto delle righe di V2
% con norma al di sotto di tol nella costruzione di V22

for i=1:nn,
    if (cont22>0),
        V22(cont22,:) = V2(nn+1-i,:);
    end
    r = rank(V22);
    if ( (r>(oldr+.5)) && (norm(V2(nn+1-i,:))>tol) ),
         X2(cont22) = nn+1-i;
         cont22=cont22-1;
         oldr = r;
      else
         %keyboard
         V21(cont21,:) = V2(nn+1-i,:);
         X1(cont21) = nn+1-i;
         cont21 = cont21-1;
    end
end

A=-V21*inv(V22);

%% RIDUCI



n = obj.joints_num;

par = rand(npar,1);

q = rand(n,1);
dq = rand(n,1);
ddq = rand(n,1);



for i=1:M
   tau_completo(:,i) = P(n*(i-1)+1:n*i,:)*par;
end



con=1;
indX1 = [];
indX2 = [];
for i=1:npar
   if ((any(Xi==i)==0)&&(any(Xni==i)==0))
      if (any(X1==con)==1)
         indX1 = [indX1; i];
      else
         indX2 = [indX2; i];
      end
      con=con+1;
   end
end

K_alta = zeros(length(Xi), npar);
for i = 1:length(Xi)
    K_alta(i,Xi(i)) = 1;
end

K_bassa = zeros(length(indX1), npar);
for i = 1:length(indX1)
    K_bassa(i,indX1(i)) = 1;
end

K_bassa(:,indX2) = A;

K = [K_alta; K_bassa]; 

for i = 1:size(K,1)
    for j = 1:size(K,2)
        if abs(K(i,j))<=1e-10
            K(i,j)=0;
        end
    end
end

par_ridotto = [par(Xi); par(indX1)+A*par(indX2)];

for i=1:M
   tau_ridotto(:,i) = P(n*(i-1)+1:n*i,[Xi; indX1])*par_ridotto;
   diff_tau(i) = norm( tau_completo(:,i) - tau_ridotto(:,i) );
end


disp('La norma dell errore di coppia �');
diff = norm(tau_completo-tau_ridotto);
disp(diff);
if diff >= 1e-10;
    error('La riduzione non � andata a buon fine, la norma dell errore � maggiore di e-10' );

end

Y_rid = obj.Y(:,[Xi; indX1]);


% ---------
% ---------
% salva gli elementi della matrice regressore in formato testo


PI = [];
for i=1:obj.links_num
    PI_temp{i}(1) = obj.links(i).m_sym;
    PI_temp{i}(2:4) = obj.links(i).mp_sym;
    PI_temp{i}(5) = obj.links(i).I_sym(1,1);
    PI_temp{i}(6) = obj.links(i).I_sym(2,1);
    PI_temp{i}(7) = obj.links(i).I_sym(3,1);
    PI_temp{i}(8) = obj.links(i).I_sym(2,2);
    PI_temp{i}(9) = obj.links(i).I_sym(2,3);
    PI_temp{i}(10) = obj.links(i).I_sym(3,3);
    PI_temp{i}(11) = obj.links(i).Fv_sym;
    PI_temp{i}(12) = obj.links(i).Fs_sym;

    PI = [PI; PI_temp{i}'];
end

PI_rid = K*PI;



scriptname = sprintf('%s.txt', 'parametriRidotto');
fid = fopen(scriptname, 'wt'); %and use 't' with text files so eol are properly translated

for i=1:length(K(:,1))
    fprintf(fid, 'PI_rid(%d) = %s;\n', i,char(vpa(PI_rid(i),4)));
    
end

fclose(fid);

disp('RIDUCI---Fine riduci');


end

