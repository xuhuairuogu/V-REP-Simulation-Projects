%Function for control a VREP simulator for ball and plate task
%obj is the class object
%object_name is the name of the object in the VREP scene
%P_b: Position of the ball respect the world frame [m]
%O_b: Orientation of the ball respect the world frame (Euler angles [x y z])[rad]


function[force, torque] =  Get_force(obj, object_handle)
   
    %Get object position
    [res, state,force,torque] = obj.vrep.simxReadForceSensor(obj.clientID,object_handle,obj.vrep.simx_opmode_streaming);

end
       
