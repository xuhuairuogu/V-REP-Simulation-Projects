%Set all joint absolute position
%obj is the class object
%q is the joints vector
function [q_right, q_left] = Get_joint_position(obj)
  
    vrep=obj.vrep;
    clientID=obj.clientID;
    joint=obj.joint;
       
    motorId=[joint(1) joint(2) joint(3) joint(4) joint(5) joint(6) joint(7) joint(8) joint(9) joint(10) joint(11) joint(12)];

    [code, q_right(1)] = vrep.simxGetJointPosition(clientID,motorId(1),vrep.simx_opmode_oneshot);
    [code, q_right(2)] = vrep.simxGetJointPosition(clientID,motorId(2),vrep.simx_opmode_oneshot);
    [code, q_right(3)] = vrep.simxGetJointPosition(clientID,motorId(3),vrep.simx_opmode_oneshot);
    [code, q_right(4)] = vrep.simxGetJointPosition(clientID,motorId(4),vrep.simx_opmode_oneshot);
    [code, q_right(5)] = vrep.simxGetJointPosition(clientID,motorId(5),vrep.simx_opmode_oneshot);
    [code, q_right(6)] = vrep.simxGetJointPosition(clientID,motorId(6),vrep.simx_opmode_oneshot);
    [code, q_left(1)] = vrep.simxGetJointPosition(clientID,motorId(7),vrep.simx_opmode_oneshot);
    [code, q_left(2)] = vrep.simxGetJointPosition(clientID,motorId(8),vrep.simx_opmode_oneshot);
    [code, q_left(3)] = vrep.simxGetJointPosition(clientID,motorId(9),vrep.simx_opmode_oneshot);
    [code, q_left(4)] = vrep.simxGetJointPosition(clientID,motorId(10),vrep.simx_opmode_oneshot);
    [code, q_left(5)] = vrep.simxGetJointPosition(clientID,motorId(11),vrep.simx_opmode_oneshot);
    [code, q_left(6)] = vrep.simxGetJointPosition(clientID,motorId(12),vrep.simx_opmode_oneshot);
 
     
  
   end