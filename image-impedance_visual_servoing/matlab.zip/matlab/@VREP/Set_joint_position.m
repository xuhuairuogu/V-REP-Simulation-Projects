%Set all joint absolute position
%obj is the class object
%q is the joints vector
function [] = Set_joint_position(obj, q_right, q_left)
  
    vrep=obj.vrep;
    clientID=obj.clientID;
    joint=obj.joint;
       
    motorId=[joint(1) joint(2) joint(3) joint(4) joint(5) joint(6) joint(7) joint(8) joint(9) joint(10) joint(11) joint(12)];

    vrep.simxSetJointTargetPosition(clientID,motorId(1),q_right(1),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(2),q_right(2),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(3),q_right(3),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(4),q_right(4),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(5),q_right(5),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(6),q_right(6),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(7),q_left(1),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(8),q_left(2),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(9),q_left(3),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(10),q_left(4),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(11),q_left(5),vrep.simx_opmode_oneshot);
    vrep.simxSetJointTargetPosition(clientID,motorId(12),q_left(6),vrep.simx_opmode_oneshot);
 
     
  
   end