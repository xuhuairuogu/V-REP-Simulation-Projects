%Function for control a VREP simulator for ball and plate task
%obj is the class object
%object_name is the name of the object in the VREP scene
%P_b: Position of the ball respect the world frame [m]
%O_b: Orientation of the ball respect the world frame (Euler angles [x y z])[rad]

function[] =  Set_object_pose(obj, object_handle, P_b, O_b)
   
    %Set object position
    obj.vrep.simxSetObjectPosition(obj.clientID,object_handle,-1, P_b,obj.vrep.simx_opmode_oneshot);
    %Set object orientation
    obj.vrep.simxSetObjectOrientation(obj.clientID, object_handle,-1, O_b, obj.vrep.simx_opmode_oneshot);
end
       
