%% VREP class
classdef VREP
    %% Variables
    properties(SetAccess = private)
         vrep=0;
         clientID=0;
         joint = [];
         drone_handle = 0;
         cone_handle = 0;
         force_sensor_handle = 0;         
    end
    
    %% Costructor (open the comunication with VREP )
    %Start the simulation in vrep before calling the costructor!!!!!!!
    methods
        %It opens communication to a specific port
        function obj = VREP(port)
            obj.vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
            obj.vrep.simxFinish(-1); % just in case, close all opened connections
            obj.clientID=obj.vrep.simxStart('127.0.0.1',port ,true ,true,5000,5); %Open the comunication
            %Search all joint in the scene
            [res,obj.joint]=obj.vrep.simxGetObjects(obj.clientID,obj.vrep.sim_object_joint_type,obj.vrep.simx_opmode_oneshot_wait);
            [res, obj.force_sensor_handle] = obj.vrep.simxGetObjectHandle(obj.clientID,'Force_sensor', obj.vrep.simx_opmode_oneshot_wait);
            [res, obj.drone_handle] = obj.vrep.simxGetObjectHandle(obj.clientID,'DRONE', obj.vrep.simx_opmode_oneshot_wait);
            [res, obj.cone_handle] = obj.vrep.simxGetObjectHandle(obj.clientID,'Cone', obj.vrep.simx_opmode_oneshot_wait);

        end
    end
    
   %% Vrep visualizer
    methods (Static)
        %Set all joint absolute position
        %obj is the class object
        %q is the joints vector
        Set_joint_position(obj, q_right, q_left);
        [q_right, qleft] = Get_joint_position(obj);

    end
    
    %% Object functions
    methods(Static)
        
         %Function for control a VREP simulator for ball and plate task
         %obj is the class object
         %object_name is the name of the object in the VREP scene
         %P_b: Position of the ball respect the world frame [m]
         %O_b: Orientation of the ball respect the world frame (Euler angles [x y z])[rad]
         Set_object_pose(obj, object_hendle, P_b, O_b);
         
         %Function for control a VREP simulator for ball and plate task
         %obj is the class object
         %object_name is the name of the object in the VREP scene
         %P_b: Position of the ball respect the world frame [m]
         %O_b: Orientation of the ball respect the world frame (Euler angles [x y z])[rad]
         [P_b, O_b] =  Get_object_pose(obj, object_hendle);
         [force, torque] =  Get_force(obj, object_handle);

         
    end
    
    %% Useful functions
    methods(Static)
         q_out = DH2VREP(q_in);
    end
    
    
end
        