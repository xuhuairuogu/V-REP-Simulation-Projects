function [ q_rob ] = DH2ROB( q_dh )

q_rob = q_dh;
q_rob(1) = -q_rob(1);
%UNTITLED3 Summary of this function goes here

end

