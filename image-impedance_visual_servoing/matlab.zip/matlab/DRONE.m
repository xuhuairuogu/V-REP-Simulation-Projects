%--------------------------------------------------------------
%--------------------------LINKS-------------------------------
%--------------------------------------------------------------

%--------------------------RIGHT-------------------------------
clear all
close all
clc
dyn_par{1} = [2.0547 0.002198 0.3570 -0.0084 0.0679 -3.8195e-4 8.9920e-6 0.0014 8.4998e-4 0.0671 0.0553 0.03]';
%matlabpool open
% RODYMAN
disp('MAIN----Creazione link');


% robot length values (metres)  page 4
D1 = 0.2755;
D2 = 0.2900;
D3 = 0.1233;
D4 = 0.0741;
D5 = 0.0741;
D6 = 0; %0.1600;
e2 = 0.0070;

% alternate parameters
aa = 30;
ca = cosd(aa);
sa = sind(aa);
c2a = cosd(2*aa);
s2a = sind(2*aa);
d4b = D3 + sa/s2a*D4;
d5b = sa/s2a*D4 + sa/s2a*D5;
d6b = sa/s2a*D5 + D6;

assignin('base', 'qr_dx', deg2rad([180 180 180 0 0 180])); % vertical pose as per Fig 2
assignin('base', 'qr_sx', deg2rad([0 180 180 0 0 180])); % vertical pose as per Fig 2

%% DX ARM DH
links_dx(1)=Link('std', 'R',1, 1, [],[2],  [0,90,D1,0,0],dyn_par{1});
links_dx(2)=Link('std', 'R',2, 2, [1],[3], [D2,180,0,0,-90],dyn_par{1});
links_dx(3)=Link('std', 'R',3, 3, [2],[4], [0,90,-e2,0,90],dyn_par{1});
links_dx(4)=Link('std', 'R',4, 4, [3],[5], [0,2*aa,-d4b,0,0],dyn_par{1});
links_dx(5)=Link('std', 'R',5, 5, [4],[6], [0,2*aa,-d5b,0,-180],dyn_par{1});
links_dx(6)=Link('std', 'R',6, 6, [5],[],  [0,180,-d6b,0,0],dyn_par{1});

%% SX ARM DH
links_sx(1)=Link('std', 'R',1, 1, [],[2],  [0,90,D1,0,0],dyn_par{1});
links_sx(2)=Link('std', 'R',2, 2, [1],[3], [D2,180,0,0,-90],dyn_par{1});
links_sx(3)=Link('std', 'R',3, 3, [2],[4], [0,90,-e2,0,90],dyn_par{1});
links_sx(4)=Link('std', 'R',4, 4, [3],[5], [0,2*aa,-d4b,0,0],dyn_par{1});
links_sx(5)=Link('std', 'R',5, 5, [4],[6], [0,2*aa,-d5b,0,-180],dyn_par{1});
links_sx(6)=Link('std', 'R',6, 6, [5],[],  [0,180,-d6b,0,0],dyn_par{1});


disp('MAIN----Creazione robot');

%Base frame transformation dx
T_dx = eye(4);
T_dx(1:3,4) = [0,-0.29,0.13237];
T_dx(1:3,1:3) = [1 0 0; 0 -1 0; 0 0 -1];

%Base frame transformation sx
T_sx = eye(4);
T_sx(1:3,4) = [0,0.29,0.13237];
T_sx(1:3,1:3) = [1 0 0; 0 -1 0; 0 0 -1];

r_dx = Robot(links_dx, T_dx);
r_sx = Robot(links_sx, T_sx);

for i=1:length(r_dx.Te_sym)    
    r_dx.Te_sym{i} = r_dx.matlabFunction(r_dx.Te_sym{i}, strcat('Kinematics/dirKinNum_dx',int2str(i)) , true, false, true);
end

for i=1:length(r_sx.Te_sym)    
    r_sx.Te_sym{i} = r_sx.matlabFunction(r_sx.Te_sym{i}, strcat('Kinematics/dirKinNum_sx',int2str(i)) , true, false, true);
end


r_dx.J_sym = r_dx.matlabFunction(r_dx.J_sym, 'Kinematics/jacobianNum_dx', true, false, true);
r_sx.J_sym = r_sx.matlabFunction(r_sx.J_sym, 'Kinematics/jacobianNum_sx', true, false, true);


save arm_dx.mat r_dx;
save arm_sx.mat r_dx;

T_dx = dirKinNum_dx1(deg2rad([45 60 60 45 45 45]));
T_sx = dirKinNum_sx1(deg2rad([45 60 60 45 45 45]));

trplot(eye(4));
hold on
trplot(T_dx);
trplot(T_sx);

%matlabpool close

            
            
            