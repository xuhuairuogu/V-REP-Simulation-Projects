clear;
clc;
close all;
addpath('Kinematics');
addpath('RemApi');
%Define system variables
global vs
global CONFIG

%% Configuration parameters
CONFIG.T = 0.010;

%% V-REP CONFIGURATION AND FIRST READINGS

%Create V-REP class
vs = VREP(19997);%Port number

%Enable the synchronous mode (Blocking function call)
vs.vrep.simxSynchronous(vs.clientID,true); 
vs.vrep.simxSetFloatingParameter(vs.clientID,vs.vrep.sim_floatparam_simulation_time_step, CONFIG.T, vs.vrep.simx_opmode_oneshot_wait);
vs.vrep.simxStartSimulation(vs.clientID,vs.vrep.simx_opmode_oneshot); 
pause(1.0);

%Perform some readings to avoid initial spikes
vs.Get_object_pose(vs, vs.drone_handle);
vs.Get_joint_position(vs); pause(0.005);
vs.Get_object_pose(vs, vs.drone_handle);
vs.Get_joint_position(vs); pause(0.005);
vs.Get_object_pose(vs, vs.drone_handle);
vs.Get_joint_position(vs); pause(0.005);
[p_b, xyz_b] =  vs.Get_object_pose(vs, vs.drone_handle);
[q_dx, q_sx] = vs.Get_joint_position(vs);
q_dx = double(q_dx');
q_sx = double(q_sx');
vs.Get_force(vs,vs.force_sensor_handle);

%Move to initial pose
%CONFIG.ARM.DX.q0 = [pi; pi; pi; 0; 0; pi];
%CONFIG.ARM.SX.q0 = [0; pi; pi; 0; 0; pi];
%CONFIG.ARM.DX.q0 = [pi; 3/4*pi; 3/4*pi; 0; pi/6; pi];
%CONFIG.ARM.SX.q0 = [0; 3/4*pi; 3/4*pi; 0; pi/6; 3*pi/2];
pb_d = [-0.12 0.30 0.9];
CONFIG.ARM.DX.q0 = [3*pi/2; 5*pi/4; 3*pi/2; 0; pi/4; 3*pi/2];
CONFIG.ARM.SX.q0 = [-2*pi/4; 6*pi/8; 7*pi/16; -pi/6; -pi/5; 3*pi/2];

while norm(q_dx-CONFIG.ARM.DX.q0)+norm(q_sx-CONFIG.ARM.SX.q0)>1e-2 || ...
    norm(pb_d-p_b)>1e-3,
    vs.vrep.simxSynchronousTrigger(vs.clientID); 
    vs.Set_joint_position(vs, CONFIG.ARM.DX.q0, CONFIG.ARM.SX.q0);
    vs.Set_object_pose(vs, vs.drone_handle, pb_d, xyz_b);
    [q_dx, q_sx] = vs.Get_joint_position(vs);
    [p_b, xyz_b] =  vs.Get_object_pose(vs, vs.drone_handle);
    q_dx = double(q_dx');
    q_sx = double(q_sx');
end

p_b = double(p_b');
xyz_b = double(xyz_b');
zyx_b = [xyz_b(3) xyz_b(2) xyz_b(1)];
%R_b = zyx2R(zyx_b);
%q_b = R2q(R_b);

vr_x = [p_b;xyz_b;q_dx;q_sx];
H_sx = dirKinNum_sx(vr_x);
H_dx = dirKinNum_dx(vr_x);



%% UAV parameters
CONFIG.UAV.m = 25; %mass [kg]
CONFIG.UAV.J = [1e-1 0 0; 0 1e-1 0; 0 0 2e-1]*10; %Inertial tenson [kg/m^2]
CONFIG.UAV.invJ = inv(CONFIG.UAV.J); 
CONFIG.UAV.g = 9.81; %Gravity acceleration [m/s^2]
CONFIG.UAV.p0 = p_b; %Initial UAV position
CONFIG.UAV.dp0 = zeros(3,1); %Initial UAV velocity
CONFIG.UAV.w0 = zeros(3,1); %Initial UAV angular velocity
CONFIG.UAV.yaw0 = zyx_b(1); %Initial UAV yaw orientation
CONFIG.UAV.dyaw0 = 0; %Initial UAV yaw orientation
CONFIG.UAV.rpy0 = [CONFIG.UAV.yaw0;0;0]; %Initial UAV orientation (roll-pitch-yaw)
CONFIG.UAV.R0 = zyx2R(CONFIG.UAV.rpy0); %Initial UAV orientation
CONFIG.UAV.q0 = R2q(CONFIG.UAV.R0); %Initial UAV orientation (unit quaternion)


%% Controller parameters 

CONFIG.UAV.CTRL.ANGLE_SAT = pi/9;

%ta circa 1 secondo senza sovraelongazione
CONFIG.UAV.CTRL.KpR = [150; 150; 100];
CONFIG.UAV.CTRL.KdR = [20; 20; 15];

% zita_d = 0.8; ta = 5; wn_d = 4/ta/zita_d;
% CONFIG.UAV.CTRL.KpP = CONFIG.UAV.m * wn_d^2; %kp=m*sqrt(wn)
% CONFIG.UAV.CTRL.KdP = 2*zita_d*CONFIG.UAV.m*wn_d; %kd=2*zita*m*wn

%x,y: ta circa 3 secondi, sovraelongazione circa 5%
%z: ta circa 2.5 secondi, sovraelongazione circa 20%
CONFIG.UAV.CTRL.KpP = [2.5; 2.5; 25];
CONFIG.UAV.CTRL.KdP = 2*[2.5; 2.5; 5];


%% ARMS CONFIGURATION (SX: camera; DX: oggetto)
CONFIG.ARM.DX.q0 = q_dx;
CONFIG.ARM.SX.q0 = q_sx;

CONFIG.ARM.DX.dq0 = zeros(6,1);
CONFIG.ARM.SX.dq0 = zeros(6,1);

CONFIG.ARM.DX.x0 = [H_dx(1:3,4);R2q(H_dx(1:3,1:3))];
CONFIG.ARM.SX.x0 = [H_sx(1:3,4);R2q(H_sx(1:3,1:3))];

q_max = [2*pi;  15*pi/8; 15*pi/8; pi;  pi; 2*pi];
q_min = [-2*pi; pi/8;   pi/8;   -pi; -pi; -2*pi];
CONFIG.ARM.q_max = [q_max; q_max];
CONFIG.ARM.q_min = [q_min; q_min];

%Posa della camera in terna end-effector (del braccio SX)
CONFIG.ARM.Hec = [-1 0 0 0;
                  0 -1 0 0;
                  0 0 1 0;
                  0 0 0 1];


%% ARM PID note
% Il tempo di assestamento dei PID di basso livello ? 200ms, no
% sovraelongazione

%% ARM CLICK
%kp = 25; ko = 25;
kp = 50; ko = 25;
CONFIG.ARM.CLIK_II.Kp = [kp;kp;kp;ko;ko;ko;kp;kp;kp;ko;ko;ko];
%kp = 15; ko = 7.5;
kp = 20; ko = 7.5;
CONFIG.ARM.CLIK_II.Kd = [kp;kp;kp;ko;ko;ko;kp;kp;kp;ko;ko;ko];

CONFIG.ARM.CLIK_II.ddq_max = [0.25; 0.25; 0.5; pi/2; 6*pi*ones(12,1)];
CONFIG.ARM.CLIK_II.dq_max = [1; 1; 2; pi/3; pi*ones(12,1)];

CONFIG.ARM.CLIK_II.Kd_ddq0 = 7.5;

CONFIG.ARM.CLIK_II.Kjl = 10;
CONFIG.ARM.CLIK_II.Tjl = 0.5;
CONFIG.ARM.CLIK_II.Tjl_safe = 0.75;
CONFIG.ARM.CLIK_II.MaxScaleFactorKjl_safe = 3;

CONFIG.ARM.CLIK_II.Kman = 10;

kp = 100; ko = 20;
CONFIG.ARM.CLIK.Kp = [kp;kp;kp;ko;ko;ko;kp;kp;kp;ko;ko;ko];


%% Controllo di ammettenza
CONFIG.ARM.ADMITTANCE_CTRL.Active = 1; %0: non attivo, 1: attivo
% mp = 10;
% kp = 100;
% zitap=0.8;
% CONFIG.ARM.ADMITTANCE_CTRL.Mp = mp*eye(3);
% CONFIG.ARM.ADMITTANCE_CTRL.Dp = 2*zitap*sqrt(mp*kp)*eye(3);
% CONFIG.ARM.ADMITTANCE_CTRL.Kp = kp*eye(3);
% CONFIG.ARM.ADMITTANCE_CTRL.Mo = 0.25*eye(3);
% CONFIG.ARM.ADMITTANCE_CTRL.Do = 3.5*eye(3);
% CONFIG.ARM.ADMITTANCE_CTRL.Ko = 2.5*eye(3);
CONFIG.ARM.ADMITTANCE_CTRL.Mp = 9;
CONFIG.ARM.ADMITTANCE_CTRL.Dp = 2000;
CONFIG.ARM.ADMITTANCE_CTRL.Kp = 0;
CONFIG.ARM.ADMITTANCE_CTRL.Mo = 0.4;
CONFIG.ARM.ADMITTANCE_CTRL.Do = 5;
CONFIG.ARM.ADMITTANCE_CTRL.Ko = 0;

CONFIG.ARM.ADMITTANCE_CTRL.invMp = inv(CONFIG.ARM.ADMITTANCE_CTRL.Mp);
CONFIG.ARM.ADMITTANCE_CTRL.invMo = inv(CONFIG.ARM.ADMITTANCE_CTRL.Mo);

CONFIG.ARM.ADMITTANCE_CTRL.F_SOGLIA.NF_max = 1;
CONFIG.ARM.ADMITTANCE_CTRL.F_SOGLIA.NM_max = 0.2;


%% CAMERA VIEW
CONFIG.CAMVIEW.SHOW = false;%true;%
CONFIG.CAMVIEW.FIG = 1;
CONFIG.CAMVIEW.SIZE = [1024 1024]/2;
CONFIG.CAMVIEW.FoV = 100;
CONFIG.CAMVIEW.FPS = 25;
fps = 1/(round((1/CONFIG.CAMVIEW.FPS)/CONFIG.T)*CONFIG.T);
if fps ~= CONFIG.CAMVIEW.FPS
    fprintf('Corretto i FPS della telecamera da %i a %i per incompatibilit? con il periodo di campionamento (%.3fs).\n\n',CONFIG.CAMVIEW.FPS,fps,CONFIG.T);
    CONFIG.CAMVIEW.FPS = fps;
end
if CONFIG.CAMVIEW.SHOW
    figure(CONFIG.CAMVIEW.FIG);
    hf_pos = [100 100];%get(VIDEO.HF,'Position');
    set(CONFIG.CAMVIEW.FIG,...
        'Position',[hf_pos(1) hf_pos(2) CONFIG.CAMVIEW.SIZE],...
        'Name','UNINA - Camera View',...
        'NumberTitle','off',...
        'ToolBar','none',...
        'MenuBar','none',...
        'Color','white');
end


%% Oggetti

%Target a terra
CONFIG.OBJs.H_wt = eye(4); %Posa del target in terna mondo
d = 0.15;
CONFIG.OBJs.Pti = [...
     d  d 0.1 1;
     d -d 0.1 1;
    -d -d 0.1 1;
    -d  d 0.1 1];
Np = size(CONFIG.OBJs.Pti,1);
if false,
    %Oggetto trasportato
    CONFIG.OBJs.Poi = [...
          0.02 -0.03 0.025 1;
         -0.02 -0.03 0.025 1;
         -0.02 -0.03 0.055 1;
          0.02 -0.03 0.055 1];
    CONFIG.IBVS.sigma0_d = [0.7984; 0.3442; 0.4900; -0.1033; -0.1247; 0.1494; -0.2532; 0.7614];
else
    %Oggetto trasportato (virtuale)
    potd = [0; 0; 0.155];
    %qotd = [0; 1; 0; 0];
    qotd = R2q(zyx2R([0;2/180*pi;pi]));
    CONFIG.xotd = [potd; qotd]; %Posizione desiderata dell'oggetto trasportato rispetto al target
    Hot = [q2R(CONFIG.xotd(4:7)) CONFIG.xotd(1:3); 0 0 0 1]; %Supposto che la terna oggetto sia coincidente con quella world
    Hto = inv(Hot);
    CONFIG.OBJs.Poi = zeros(size(CONFIG.OBJs.Pti));
    for i=1:Np
        CONFIG.OBJs.Poi(i,:) = (Hto*CONFIG.OBJs.Pti(i,:)')';
    end
    CONFIG.IBVS.sigma0_d = zeros(2*Np,1);
end
  
%% Controllo Visuale (IBVS)
% std = [...
%     0.5938   -0.2623
%     0.1574   -0.6218
%    -0.3857   -0.2722
%    -0.3945    0.2612 ];
% sod = [...
%    -0.2047   -0.6065
%    -0.3326   -0.5185
%    -0.2609   -0.4216
%    -0.1414   -0.5002 ];

CONFIG.IBVS.Ko = 0.25;

CONFIG.IBVS.Kc0 = 0.2  
CONFIG.IBVS.Kcom = 0.2;  
CONFIG.IBVS.Th_com = 0.15;  
  
CONFIG.IBVS.dp_max = 0.1;
CONFIG.IBVS.w_max = pi/4;

CONFIG.IBVS.OA.Active = false;
CONFIG.IBVS.OA.D_th = 0.3;


%% Object (Cone)
%CONFIG.OBJECT.Release = false;
CONFIG.OBJECT.CoM = [0;0;0.0810]; %Posizione del CoM dell'oggetto
CONFIG.OBJECT.Mass = 1.0; %Massa dell'oggetto
CONFIG.OBJECT.I = 1e-5; %Ineriza dell'oggetto
CONFIG.OBJECT.Pi = [...
    0.03 0.03 0 1;
    -0.03 0.03 0 1;
    -0.03 -0.03 0 1;
    0.03 -0.03 0 1;
    0.03 0.03 0.06 1;
    -0.03 0.03 0.06 1;
    -0.03 -0.03 0.06 1;
    0.03 -0.03 0.06 1;
    0 0 0.13 1];
    


