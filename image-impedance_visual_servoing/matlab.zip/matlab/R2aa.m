function [r,theta] = R2aa(R)
%Rappresentazione asse angolo corrispondente alla matrice di rotazione R
%#codegen

theta = acos(0.5*(R(1,1)+R(2,2)+R(3,3)-1));
if (sin(theta) ~= 0)
    r = [R(3,2)-R(2,3); R(1,3)-R(3,1); R(2,1)-R(1,2)]/(2*sin(theta));
else
    r = [1;0;0];
end


