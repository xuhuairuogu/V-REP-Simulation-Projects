
function xyz = R2xyz(R)
%Restituisce gli angoli di Eulero XYZ corrispondenti alla matrice di
%rotazione data in ingresso
%#codegen

xyz = [0;0;0];
if (R(3,1)<1)&&(R(3,1)>-1)
    xyz(3) = atan2(R(2,1),R(1,1));
    xyz(2) = atan2(-R(3,1),sqrt(R(3,2)^2+R(3,3)^2));
    xyz(1) = atan2(R(3,2),R(3,3));
elseif ((R(3,2)~=0)&&(R(3,3)~=0))
    fprintf('Attenzione: singolarit� di rappresentazione\n');
    %xyz(3) = 0;
    xyz(2) = atan2(R(2,1),R(1,1));
    %xyz(1) = 0;
end

