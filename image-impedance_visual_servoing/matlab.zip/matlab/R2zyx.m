
function zyx = R2zyx(R)
%Restituisce gli angoli di Eulero ZYX corrispondenti alla matrice di
%rotazione data in ingresso
%#codegen

zyx = [0;0;0];
if (R(3,1)<1)&&(R(3,1)>-1)
    zyx(1) = atan2(R(2,1),R(1,1));
    zyx(2) = atan2(-R(3,1),sqrt(R(3,2)^2+R(3,3)^2));
    zyx(3) = atan2(R(3,2),R(3,3));
elseif ((R(3,2)~=0)&&(R(3,3)~=0))
    fprintf('Attenzione: singolarit� di rappresentazione\n');
    %zyx(1) = 0;
    zyx(2) = atan2(R(2,1),R(1,1));
    %zyx(3) = 0;
end

