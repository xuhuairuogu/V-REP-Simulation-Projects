function [xt,dxt,ddxt]  = TrajectoryPlanner(t,times,poses)

N = length(times);
if t<=times(1)
    xt = poses(1,:)';
    dxt = zeros(6,1);
    ddxt = zeros(6,1);
elseif t>=times(N)
    xt = poses(N,:)';
    dxt = zeros(6,1);
    ddxt = zeros(6,1);
else
    %Trova il segmento da tracciare
    index = 2;
    while t > times(index)
        index = index+1;
    end
    t0 = times(index-1);
    tf = times(index);
    x0 = poses(index-1,:)';
    xf = poses(index,:)';
    %Scala il tempo iniziale
    t = t-t0; 
    tf = tf-t0;
    %Ascissa curvilinea
    a = 4/tf^2; %Massima accelerazione
    tc = 0.5*(tf-sqrt((tf*tf*a-4)/a));
    if (t<=0)
        s=0;
        ds = 0;
        dds = 0;
    elseif (t<=tc)
        s=0.5*a*t*t;
        ds = a*t;
        dds = a;
    elseif (t<=tf-tc)
        s=a*tc*(t-0.5*tc);
        ds = a*tc;
        dds = 0;
    elseif (t<tf)
        s=1-0.5*a*(tf-t)^2;
        ds = a*(tf-t);
        dds = -a;
    else
        s=1;
        ds = 0;
        dds = 0;
    end    
    %Orientamento iniziale
    Ri = q2R(x0(4:7));
    Rf = q2R(xf(4:7));
    Rif = Ri'*Rf;
    [v,a] = R2aa(Rif);
    %Calcola la traiettoria
    dp = xf(1:3)-x0(1:3);
    vwf = Ri*(a*v);
    xt = [ x0(1:3,1) + s*dp; R2q(Ri*aa2R(v,s*a))];
    dxt = [ ds*dp; ds*vwf ];
    ddxt = [ dds*dp; dds*vwf ];
end


