%% Simple main file to use RoDyMan class
%% DEFINE VREP OBJECT
clc;
clear all;
close all;
v = VREP(19997);%Port number
%You must define that in file remoteApiConnections located in VREP
%installation path

%%I fori sulla piastra sono sui vertici di un quadrato di lati 300X300mm


%% START SIMULATION
v.vrep.simxSynchronous(v.clientID,true); %Enable the synchronous mode (Blocking function call)
res = v.vrep.simxStartSimulation(v.clientID,v.vrep.simx_opmode_oneshot);

pause(1)
for i=1:5,
    v.Get_joint_position(v);
end

%Variable
assignin('base', 'qr_dx', deg2rad([180 180 180 0 0 180])); % right arm zero position
assignin('base', 'qr_sx', deg2rad([90 180-60 180-45 0 0 180])); % left arm zero position

for i=1:300
    tic;
    % Trigger next simulation step (Blocking function call)
    v.vrep.simxSynchronousTrigger(v.clientID); 
    
    %Read arm joint position
    [q_dx_m(i,:), q_sx_m(i,:)] = v.Get_joint_position(v);
    
    %Set arms joint position
    q_dx(i,:) = qr_dx+0.5*sin(0.2*2*pi*i*0.02)*ones(1,6); %q is DH joint vector (DH2VREP convert the joint vector from DH joint space to VREP joint space, there are an offset)
    q_sx(i,:) = qr_sx+0.5*sin(0.2*2*pi*i*0.02)*ones(1,6); %q is DH joint vector (DH2VREP convert the joint vector from DH joint space to VREP joint space, there are an offset)
    v.Set_joint_position(v, q_dx(i,:), q_sx(i,:));
    
    while(toc<=0.001);end
    
end


figure(1)
plot(q_dx_m);
hold on
plot(q_dx);
title('q_dx')

figure(2)
plot(q_sx_m)
hold on
plot(q_sx);
title('q_sx')


%% MOVE THE ROBOT

%% GET OBJECT POSE
%P_e is the actual position
%O_e is the actual orientation in euler angles (x y z)
[P_e, O_e] =  v.Get_object_pose(v, v.drone_handle);
P_d = P_e;
O_d=O_e;

%% SET OBJECT POSE
%P_e is the actual position
%O_e is the actual orientation in euler angles (x y z)
v.Set_object_pose(v, v.drone_handle, P_e, O_d);

v.vrep.simxSynchronousTrigger(v.clientID); % Trigger next simulation step (Blocking function call)
t = 0;
k=-1;
%Control
for i=1:200
    tic;
    q_dx(i,:) = qr_dx;%deg2rad([45 60 60 45 45 45]);%+0.5+sin(0.2*2*pi*i*0.02)*ones(1,6); %q is DH joint vector (DH2VREP convert the joint vector from DH joint space to VREP joint space, there are an offset)
    q_sx(i,:) = qr_sx;%+0.5+sin(0.2*2*pi*i*0.02)*ones(1,6); %q is DH joint vector (DH2VREP convert the joint vector from DH joint space to VREP joint space, there are an offset)
    P_d(1) = P_e(1);
    P_d(2) = P_e(2);
    P_d(3) = P_e(3) + t;%0.11*sin(0.2*2*pi*i*0.01);
    P_d = P_d + [0 0 0];
    
    %Get force and torque
    [force(i,:),torque(i,:)] = v.Get_force(v,v.force_sensor_handle);
    
    %Set position and orientation of the Drone
    %P_e is the actual position
    %O_e is the actual orientation in euler angles (x y z)
    v.Set_object_pose(v, v.drone_handle, P_d, O_d);
    
    %Set arms joint position
    v.Set_joint_position(v,q_dx(i,:),q_sx(i,:));
    
    [q_dx_m(i,:), q_sx_m(i,:)] = v.Get_joint_position(v);
    
    v.vrep.simxSynchronousTrigger(v.clientID); % Trigger next simulation step (Blocking function call)
    if i==120
        %Release the cone
        v.vrep.simxSetObjectParent(v.clientID,v.cone_handle,-1,-1,v.vrep.simx_opmode_oneshot);
        k=1;
    end
    t = t + k*0.001;
    while(toc<=0.2);end
    
end

pause(2);
%% STOP SIMULATION

res = v.vrep.simxStopSimulation(v.clientID,v.vrep.simx_opmode_oneshot);

figure(3)
plot(force(10:end,:));
title('Force'); 
legend('Fx', 'Fy', 'Fz');
figure(4)
plot(torque(10:end,:));title('Torque'); legend('Tx', 'Ty', 'Tz');

figure(5)
plot(q_dx_m);
hold on
plot(q_dx);
title('q_dx')

figure(6)
plot(q_sx_m)
hold on
plot(q_sx);
title('q_sx')

