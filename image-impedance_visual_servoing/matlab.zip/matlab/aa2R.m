function R = aa2R(r,theta)
%Matrice di rotazione individuata con una rappresentazione asse angolo
%#codegen

ct=cos(theta); st=sin(theta);
uno_ct = 1-ct;
rx=r(1); ry=r(2); rz=r(3);
R = [rx*rx*uno_ct+ct rx*ry*uno_ct-rz*st rx*rz*uno_ct+ry*st;
     rx*ry*uno_ct+rz*st ry*ry*uno_ct+ct ry*rz*uno_ct-rx*st;
     rx*rz*uno_ct-ry*st ry*rz*uno_ct+rx*st rz*rz*uno_ct+ct];