function [ c, ceq ] = confuneq( x )

obj_=load( 'rodyman_wo_base.mat' );
obj = obj_.r;
c = [];
ceq = [];

n_joints = obj.joints_num;

f = 0.1;
wf = 2*pi*f;

t = 0;
Ni = 5;

Ts_ott = 0.05;
N = 1/f/Ts_ott;

q0 = [];

n_x = ( 2*Ni + 1 ) * n_joints;
n_g = ( 2*Ni + 1 );

for j = 1:obj.joints_num
    q0 = [q0; x(n_g*(j-1)+1)];
end

qmin = pi/180*[-90; -30; -90; 0; -45; -60; -180;-120 ;-180; -90; 0; -45; -60; -180;-120 ;-180;  ];
qmax = pi/180*[90; 30; 90; 120; 45; 60; 180; 120; 180; 90; 120; 45; 60; 180; 120; 180 ];
dqmax = [ 0.418; 0.418; 0.418; 1.25; 1.25; 1.25; 1.25; 1.25; 1.25; 0.418; 1.25; 1.25; 1.25; 1.25; 1.25; 1.25 ];
dqmax = dqmax;
dqmin = -dqmax;
zmin = 0.2;
rmin = 0.15;
q_max = -1000*ones(n_joints,1);
q_min = 1000*ones(n_joints,1);
dq_max = -1000*ones(n_joints,1);
dq_min = 1000*ones(n_joints,1);

for i = 1:N
    
    q = q0;
    dq = zeros(n_joints, 1);
    ddq = zeros(n_joints, 1);
    

    for k = 1:n_joints
        for j = 1:Ni
        
        
            
            q(k) = q(k) + x( n_g*(k-1)+j+1 ) / ( wf*j ) * sin( wf*j*t ) - x( n_g*(k-1)+j+1+Ni ) / ( wf*j ) * cos( wf*j*t );
            dq(k) = dq(k) + x( n_g*(k-1)+j+1 ) * cos( wf*j*t ) + x( n_g*(k-1)+j+1+Ni )  * sin( wf*j*t );
            ddq(k) = ddq(k) - x( n_g*(k-1)+j+1 ) * ( wf*j ) * sin( wf*j*t ) + x( n_g*(k-1)+j+1+Ni ) * ( wf*j ) * cos( wf*j*t );
            

        
        end
        
        c = [c; -q(k) + qmin(k); q(k) - qmax(k); -dq(k) + dqmin(k); dq(k) - dqmax(k) ];

        
%         if q(k) > q_max(k)
%             q_max(k) = q(k);
%         end
%         
%         if q(k) < q_min(k)
%             q_min(k) = q(k);
%         end
%         
%         if dq(k) > dq_max(k)
%             dq_max(k) = dq(k);
%         end
%         
%         if dq(k) < dq_min(k)
%             dq_min(k) = dq(k);
%         end
%         
        
        
    end
  
    t = t + Ts_ott;

end

end

