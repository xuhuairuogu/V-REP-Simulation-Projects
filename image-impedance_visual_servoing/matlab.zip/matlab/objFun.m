function fun = objFun( x )

obj_=load( 'rodyman_wo_base.mat' );
obj = obj_.r;
n_joints = obj.joints_num;

f = 0.1;
wf = 2*pi*f;

t = 0;
Ni = 5;

W = [];

Ts_ott = 0.05;
N = 1/f/Ts_ott;

q0 = [];
n_x = ( 2*Ni + 1 ) * n_joints;
n_g = ( 2*Ni + 1 );

for j = 1:obj.joints_num
    q0 = [q0; x(n_g*(j-1)+1)];
end

for i = 1:N
    
    q = q0;
    dq = zeros(n_joints, 1);
    ddq = zeros(n_joints, 1);
    
    for j = 1:Ni
        
        for k = 1:n_joints
            
            q(k) = q(k) + x( n_g*(k-1)+j+1 ) / ( wf*j ) * sin( wf*j*t ) - x( n_g*(k-1)+j+1+Ni ) / ( wf*j ) * cos( wf*j*t );
            dq(k) = dq(k) + x( n_g*(k-1)+j+1 ) * cos( wf*j*t ) + x( n_g*(k-1)+j+1+Ni )  * sin( wf*j*t );
            ddq(k) = ddq(k) - x( n_g*(k-1)+j+1 ) * ( wf*j ) * sin( wf*j*t ) + x( n_g*(k-1)+j+1+Ni ) * ( wf*j ) * cos( wf*j*t );
        
        end
        
    end
    
    W1 = regressorNumRid( q, dq, ddq );
    
    W = [ W; W1 ];
    
    t = t + Ts_ott;



end


for i = 1:length( W(1,:) )
    W( :,i ) = W(:,i);
    
end

fun = cond(W);
end

