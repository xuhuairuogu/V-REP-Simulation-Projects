function plot_paper

sel = 3;
switch(sel)
    case 1
    sim_name = 'JT-';
    file_dat = 'JT.mat';
    case 2
    sim_name = 'JI-';
    file_dat = 'JI.mat';
    case 3
    sim_name = 'II-';
    file_dat = 'II.mat';
end
load(file_dat)

close all
fig = 0;
font_size = 10;
plot_size_x = 400;
plot_size_y = 300;


%Color order
dco = [0    0.4470    0.7410
    0.8500    0.3250    0.0980
    0.9290    0.6940    0.1250
    0.4940    0.1840    0.5560
    0.4660    0.6740    0.1880
    0.3010    0.7450    0.9330
    0.6350    0.0780    0.1840
    0.2500    0.2500    0.2500 ];
co = [1 0 0;
      0 1 0;
      0 0 1;
      1 0 1];
set(groot,'defaultAxesColorOrder',dco)

%Positional error
filename = 'ep';
x = ep.Data;
tt = ep.Time;
um = 'm';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Positional error
filename = 'eo';
x = eo.Data;
tt = eo.Time;
um = 'deg';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Contact force
filename = 'force';
x = ft_c.Data(:,1:3);
tt = ft_c.Time;
um = 'N';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Contact moment
filename = 'moment';
x = ft_c.Data(:,4:6);
tt = ft_c.Time;
um = 'Nm';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Visual error
filename = 'ev';
x = e_vs.Data;
tt = e_vs.Time;
um = 'm';
set(groot,'defaultAxesColorOrder',dco)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Camera view
filename = 'camera_view';
n = size(so.Data,3);
sod = zeros(n,8);
std = zeros(n,8);
for i=1:n,
    sod(i,1:2) = so.Data(1,1:2,i);
    sod(i,3:4) = so.Data(2,1:2,i);
    sod(i,5:6) = so.Data(3,1:2,i);
    sod(i,7:8) = so.Data(4,1:2,i);
    std(i,1:2) = st.Data(1,1:2,i);
    std(i,3:4) = st.Data(2,1:2,i);
    std(i,5:6) = st.Data(3,1:2,i);
    std(i,7:8) = st.Data(4,1:2,i);
end
for i=1:4
    sod(:,2*i) = -sod(:,2*i);
    std(:,2*i) = -std(:,2*i);
end
x2 = std;
x1 = sod;
um = 'X';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
if(0)
    x = [x1(end,1);x1(end,3);x1(end,5);x1(end,7)];
    y = [x1(end,2);x1(end,4);x1(end,6);x1(end,8)];
    xf = [x2(end,1);x2(end,3);x2(end,5);x2(end,7)];
    yf = [x2(end,2);x2(end,4);x2(end,6);x2(end,8)];
    u=xf-x; v=yf-y;
    quiver(x,y,u,v,0,'Color',[0.25 0.25 0.25],'LineWidth', 2);
    hold on
end
if (1)
    D = 1.1*tand(CONFIG.CAMVIEW.FoV/2);
    plot([-D;-D;D;D;-D],[-D;D;D;-D;-D],'k','LineWidth',3);
hold on
    D = 0.8*tand(CONFIG.CAMVIEW.FoV/2);
    plot([-D;-D;D;D;-D],[-D;D;D;-D;-D],'r--','LineWidth',1);
end
plot(x1(:,1),x1(:,2),x1(:,3),x1(:,4),x1(:,5),x1(:,6),x1(:,7),x1(:,8));
hold on
plot(x1(1,1),x1(1,2),'o',x1(1,3),x1(1,4),'o',x1(1,5),x1(1,6),'o',x1(1,7),x1(1,8),'o');
plot(x1(end,1),x1(end,2),'x',x1(end,3),x1(end,4),'x',x1(end,5),x1(end,6),'x',x1(end,7),x1(end,8),'x');
%plot(x2(:,1),x2(:,2),'--',x2(:,3),x2(:,4),'--',x2(:,5),x2(:,6),'--',x2(:,7),x2(:,8),'--');
plot(x2(:,1),x2(:,2),':',x2(:,3),x2(:,4),':',x2(:,5),x2(:,6),':',x2(:,7),x2(:,8),':');
plot(x2(1,1),x2(1,2),'o',x2(1,3),x2(1,4),'o',x2(1,5),x2(1,6),'o',x2(1,7),x2(1,8),'o');
plot(x2(end,1),x2(end,2),'x',x2(end,3),x2(end,4),'x',x2(end,5),x2(end,6),'x',x2(end,7),x2(end,8),'x');

axis equal
axis([-1.5,1.5,-1.5,1.5]);
set(gca,'FontName','Times','FontSize',font_size);
xlabel('Y','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Visual Feature expansion
filename = 'ec';
x = ec.Data;
tt = ec.Time;
um = 'm';
set(groot,'defaultAxesColorOrder',dco)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );


%Visual Feature com
filename = 'vCoM';
x = ecom.Data;
tt = ecom.Time;
um = 'm';
set(groot,'defaultAxesColorOrder',co)
fig = fig + 1;
cf = figure(fig);
set(gcf,'Position',[100 100 plot_size_x plot_size_y],'Name',filename,'NumberTitle','off');
plot(tt,x)
grid on
set(gca,'FontName','Times','FontSize',font_size);
xlabel('s','Interpreter','latex','FontSize',font_size)
ylabel(um,'Interpreter','latex','FontSize',font_size)
saveas( cf, strcat(sim_name,filename), 'fig' );




set(groot,'defaultAxesColorOrder',dco)


