function R = q2R(q)
%From unit quaternion to R
%#codegen

eta=q(1);
eta2=eta*eta;
epsx=q(2); epsy=q(3); epsz=q(4);

R=2*[   eta2+epsx*epsx-0.5  epsx*epsy-eta*epsz  epsx*epsz+eta*epsy
        epsx*epsy+eta*epsz  eta2+epsy*epsy-0.5  epsy*epsz-eta*epsx
        epsx*epsz-eta*epsy  epsy*epsz+eta*epsx  eta2+epsz*epsz-0.5
    ];
end