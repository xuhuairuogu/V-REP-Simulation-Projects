function q_ft = vRepRead()
%#codegen

% Trigger next simulation step (Blocking function call)
global vs
vs.vrep.simxSynchronousTrigger(vs.clientID); 

%Read arms joints
[q_dx, q_sx] = vs.Get_joint_position(vs);


%Read vehicle base pose
% - p_b is the actual position
% - xyz_b is the actual orientation in euler angles (x y z)
[p_b, xyz_b] =  vs.Get_object_pose(vs, vs.drone_handle);
%R_b = zyx2R([xyz_b(3) xyz_b(2) xyz_b(1)]);
%q_b = R2q(R_b);
%q = [p_b'; q_b; q_dx'; q_sx'];

%Get force and torque
[force,torque] = vs.Get_force(vs,vs.force_sensor_handle);
%ft = [force'; torque'];

q_ft = [p_b'; xyz_b'; q_dx'; q_sx'; force'; torque'];
