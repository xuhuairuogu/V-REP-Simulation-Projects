function vRepWrite(xsi,release_cone)
%#codegen

% Trigger next simulation step (Blocking function call)
global vs

%Set position and orientation (xyz Euler angles) of the Drone base
p_b = xsi(1:3);
xyz_b = xsi(4:6);
%q_b = xsi(4:7);
%R_b = q2R(q_b);
%zyx_b = R2zyx(R_b);
%xyz_b = [zyx_b(3);zyx_b(2);zyx_b(1)];

vs.Set_object_pose(vs, vs.drone_handle, p_b, xyz_b);

%Set arms joint position
q_dx = xsi(7:12);
q_sx = xsi(13:18);
vs.Set_joint_position(vs, q_dx, q_sx);

%Release cone
if (release_cone)
    vs.vrep.simxSetObjectParent(vs.clientID,vs.cone_handle,-1,-1,vs.vrep.simx_opmode_oneshot);
end
