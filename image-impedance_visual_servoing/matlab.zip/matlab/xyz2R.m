function R = xyz2R(q)
%Matrice di rotazione derivata dagli angoli di Eulero XYZ
%#codegen

cf = cos(q(3)); sf = sin(q(3));
ct = cos(q(2)); st = sin(q(2));
cp = cos(q(1)); sp = sin(q(1));

R = [	cf*ct   cf*st*sp-sf*cp	cf*st*cp+sf*sp
  		sf*ct	sf*st*sp+cf*cp	sf*st*cp-cf*sp
  		-st	    ct*sp			ct*cp   		];