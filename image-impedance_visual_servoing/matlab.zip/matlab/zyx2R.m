function R = zyx2R(q)
%Matrice di rotazione derivata dagli angoli di Eulero ZYX
%#codegen

cf = cos(q(1)); sf = sin(q(1));
ct = cos(q(2)); st = sin(q(2));
cp = cos(q(3)); sp = sin(q(3));

R = [	cf*ct   cf*st*sp-sf*cp	cf*st*cp+sf*sp
  		sf*ct	sf*st*sp+cf*cp	sf*st*cp-cf*sp
  		-st	    ct*sp			ct*cp   		];